import { handcashLockupSvg, handcashMarkDataUri } from './handcashLogo.js'

const BRAND = '#35e889'
const FAVICON = handcashMarkDataUri(BRAND)
const LOGO = handcashLockupSvg({
  className: 'logo',
  height: 27,
  markFill: 'var(--green)',
  wordFill: 'currentColor',
})

const CSP = [
  "default-src 'none'",
  "style-src 'unsafe-inline'",
  "script-src 'unsafe-inline'",
  "connect-src 'self' https://127.0.0.1:2121 http://127.0.0.1:3321",
  "img-src 'self'",
  "base-uri 'none'",
  "form-action 'none'",
  "frame-ancestors 'none'",
].join('; ')

export function walletDemoHtml() {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="color-scheme" content="dark">
  <meta name="theme-color" content="${BRAND}">
  <link rel="icon" href="${FAVICON}">
  <title>HandCash Reference App · End-to-end BRC-100</title>
  <style>
    :root{--bg:#080b09;--panel:#101612;--panel2:#151d18;--line:#27322b;--text:#f0f6f2;--muted:#91a298;--green:#35e889;--green2:#1dbb6c;--yellow:#f3c84b;--red:#ff7280;--blue:#72a7ff;font-family:Inter,ui-sans-serif,system-ui,-apple-system,sans-serif}
    *{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 70% -20%,#1c5234 0,transparent 42%),var(--bg);color:var(--text);min-height:100vh}.shell{width:min(1100px,calc(100% - 28px));margin:auto;padding:22px 0 64px}
    header{display:flex;align-items:center;justify-content:space-between;padding:8px 2px 34px}.brand{display:flex;align-items:center;gap:13px}.logo{display:block}.tag{border:1px solid #397651;color:var(--green);padding:4px 8px;border-radius:999px;font:700 10px/1 ui-monospace,monospace;letter-spacing:.08em;text-transform:uppercase}.source{color:var(--muted);font-size:13px;text-decoration:none}.source:hover{color:var(--text)}
    .hero{display:grid;grid-template-columns:1.3fr .7fr;gap:30px;align-items:end;margin-bottom:28px}.eyebrow{color:var(--green);font:700 11px/1 ui-monospace,monospace;letter-spacing:.14em;text-transform:uppercase}.hero h1{font-size:clamp(40px,7vw,76px);line-height:.92;letter-spacing:-.06em;margin:15px 0}.hero h1 span{color:#829088}.lede{color:var(--muted);max-width:670px;font-size:16px;line-height:1.65}.art{display:grid;grid-template-columns:1fr 1fr;gap:10px}.art-frame{position:relative;aspect-ratio:1;border:1px solid var(--line);background:#111713;border-radius:20px;overflow:hidden}.art-frame img{width:100%;height:100%;object-fit:cover;opacity:0;transition:opacity .2s}.art-frame.ready img{opacity:1}.art-frame:before{content:"";position:absolute;inset:0;background:linear-gradient(110deg,#111713 30%,#1c2921 45%,#111713 60%);background-size:220% 100%;animation:shimmer 1.2s linear infinite}.art-frame.ready:before{display:none}.art-label{position:absolute;left:10px;bottom:9px;background:#07100bc9;border:1px solid #3b5144;border-radius:999px;padding:5px 8px;font:700 9px/1 ui-monospace,monospace;text-transform:uppercase;letter-spacing:.08em}
    .runner{border:1px solid var(--line);background:#0d120fdd;border-radius:24px;padding:22px;box-shadow:0 35px 90px #0008}.runner-top{display:flex;gap:18px;align-items:center;justify-content:space-between}.runner-copy h2{margin:0 0 6px;font-size:20px}.runner-copy p{margin:0;color:var(--muted);font-size:13px;line-height:1.5}.run{flex:none;border:0;border-radius:14px;background:linear-gradient(135deg,var(--green),var(--green2));color:#031109;padding:15px 22px;font:800 14px/1 inherit;cursor:pointer;box-shadow:0 9px 30px #21c97531}.run:disabled{opacity:.6;cursor:wait}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:18px}.metric{border:1px solid var(--line);border-radius:13px;padding:12px;background:#0a0e0b}.metric strong{display:block;font-size:19px}.metric span{display:block;color:var(--muted);font-size:10px;text-transform:uppercase;letter-spacing:.08em;margin-top:3px}
    .steps{display:grid;gap:8px;margin-top:16px}.step{display:grid;grid-template-columns:30px 1fr auto;gap:11px;align-items:start;padding:13px;border:1px solid var(--line);background:var(--panel);border-radius:14px}.step-num{width:28px;height:28px;border-radius:9px;background:#202a23;color:var(--muted);display:grid;place-items:center;font:700 11px ui-monospace,monospace}.step strong{font-size:13px}.step small{display:block;color:var(--muted);font-size:11px;line-height:1.45;margin-top:3px;word-break:break-word}.step-time{color:var(--muted);font:11px ui-monospace,monospace}.step[data-state=running]{border-color:#7d682c;background:#17160f}.step[data-state=running] .step-num{background:#42391a;color:var(--yellow);animation:pulse .9s infinite}.step[data-state=passed]{border-color:#245f3b}.step[data-state=passed] .step-num{background:#153c25;color:var(--green)}.step[data-state=failed]{border-color:#71303a}.step[data-state=failed] .step-num{background:#442027;color:var(--red)}
    details{margin-top:18px;border-top:1px solid var(--line);padding-top:16px}summary{cursor:pointer;color:var(--muted);font-size:12px}.log{margin:12px 0 0;max-height:370px;overflow:auto;background:#070a08;border:1px solid var(--line);border-radius:12px;padding:13px;color:#a9b8ae;font:11px/1.55 ui-monospace,SFMono-Regular,monospace;white-space:pre-wrap;word-break:break-word}
    .note{color:#77867d;font-size:12px;line-height:1.6;margin:18px 3px 0}.note b{color:#aebbb3}@keyframes pulse{50%{opacity:.45}}@keyframes shimmer{to{background-position:-220% 0}}@media(max-width:760px){.hero{grid-template-columns:1fr}.art{max-width:360px}.runner-top{align-items:stretch;flex-direction:column}.run{width:100%}.summary{grid-template-columns:1fr 1fr}.source{display:none}.shell{width:min(100% - 20px,1100px)}}
  </style>
</head>
<body>
<div class="shell">
  <header>
    <div class="brand">${LOGO}<span class="tag">Reference app</span></div>
    <a class="source" href="https://github.com/HandCash/BRC-CLOUD/blob/master/src/walletDemoApp.js" target="_blank" rel="noreferrer">View source ↗</a>
  </header>
  <section class="hero">
    <div>
      <p class="eyebrow">One click · real wallet · real chain</p>
      <h1>Exercise the whole<br><span>wallet–app boundary.</span></h1>
      <p class="lede">Connect, prove identity, sign and verify, encrypt and decrypt, read inventory, bounce a BRC-29 payment, mint a JPEG item and BSV-21 token, then prove both appeared in wallet inventory.</p>
    </div>
    <div class="art">
      <div class="art-frame"><img src="/wallet-demo-assets/robot.jpg" alt="Reference Robot collectable"><span class="art-label">1Sat item</span></div>
      <div class="art-frame"><img src="/wallet-demo-assets/token.jpg" alt="Reference token icon"><span class="art-label">Token icon</span></div>
    </div>
  </section>
  <section class="runner">
    <div class="runner-top">
      <div class="runner-copy"><h2>End-to-end conformance run</h2><p>One button starts the flow. HandCash will still ask for each sensitive approval.</p></div>
      <button class="run" id="run" type="button">Run everything</button>
    </div>
    <div class="summary">
      <div class="metric"><strong id="passed">0</strong><span>Passed</span></div>
      <div class="metric"><strong id="failed">0</strong><span>Failed</span></div>
      <div class="metric"><strong id="elapsed">—</strong><span>Total time</span></div>
      <div class="metric"><strong id="balance">—</strong><span>Balance sats</span></div>
    </div>
    <div class="steps" id="steps"></div>
    <details><summary>Request / response transcript</summary><pre class="log" id="log"></pre></details>
  </section>
  <p class="note"><b>Reference behavior:</b> wallet calls go directly from this browser to the local BRC-100 bridge on 127.0.0.1. Cloudflare only prepares the public BRC-29 refund and converts a public key to a P2PKH lock. No private key or wallet request passes through the Worker.</p>
</div>
<script>
(() => {
  'use strict'
  const HTTPS_BASE = 'https://127.0.0.1:2121'
  const HTTP_BASE = 'http://127.0.0.1:3321'
  const ORIGINATOR = location.host
  const BOUNCE_PROTOCOL = [2, '3241645161d8']
  const PROOF_PROTOCOL = [2, 'wallet identity proof']
  // Apps read inventory through the BRC-165 / BRC-99 permission scopes, not the
  // wallet's internal storage baskets. "1sat" and "bsv21" name where the wallet
  // keeps outputs; an app asking for those is refused with USE_P1SAT_SCOPE.
  // Filter values ride in tags, never in the basket name.
  const ITEM_SCOPE = 'p 1sat all'
  const TOKEN_SCOPE = 'p bsv21 all'
  const PENDING_KEY = 'handcash.referenceDemo.pendingBounce.v1'
  const enc = new TextEncoder()
  const dec = new TextDecoder()
  let bridgeBase = null
  let running = false
  let passed = 0
  let failed = 0

  const STEP_DEFS = [
    ['connect','Connect and inspect wallet'],
    ['identity','Identity proof: sign and verify'],
    ['crypto','Encrypt, decrypt, HMAC and verify'],
    ['inventory-before','Read item and token inventory'],
    ['bounce','Bounce a BRC-29 transaction'],
    ['mint-media','Mint two JPEG-backed 1Sat items'],
    ['mint-token','Mint a BSV-21 token'],
    ['inventory-after','Verify inventory and action history'],
  ]
  const steps = document.getElementById('steps')
  for (let i = 0; i < STEP_DEFS.length; i++) {
    const def = STEP_DEFS[i]
    const row = document.createElement('div')
    row.className = 'step'
    row.id = 'step-' + def[0]
    row.dataset.state = 'idle'
    row.innerHTML = '<span class="step-num">' + String(i + 1).padStart(2,'0') + '</span><div><strong></strong><small>Waiting</small></div><span class="step-time">—</span>'
    row.querySelector('strong').textContent = def[1]
    steps.append(row)
  }
  for (const image of document.querySelectorAll('.art-frame img')) {
    const ready = () => image.parentElement.classList.add('ready')
    image.addEventListener('load', ready, {once:true})
    if (image.complete && image.naturalWidth) ready()
  }

  function log(label, value) {
    const line = typeof value === 'string' ? value : JSON.stringify(value, null, 2)
    document.getElementById('log').textContent += '[' + new Date().toISOString() + '] ' + label + '\\n' + line + '\\n\\n'
  }
  function errorPayload(error) {
    return {message:error && error.message ? error.message : String(error), code:error && error.code ? error.code : null}
  }
  function assert(condition, message) {
    if (!condition) throw new Error(message)
  }
  async function step(id, work) {
    const row = document.getElementById('step-' + id)
    const detail = row.querySelector('small')
    const time = row.querySelector('.step-time')
    row.dataset.state = 'running'
    detail.textContent = 'Running…'
    announceStep(id)
    const started = performance.now()
    try {
      const result = await work(message => {
        detail.textContent = message
        announceStep(id, message)
      })
      const duration = Math.round(performance.now() - started)
      row.dataset.state = 'passed'
      detail.textContent = result && result.summary ? result.summary : 'Passed'
      time.textContent = duration + 'ms'
      passed += 1
      document.getElementById('passed').textContent = passed
      return result
    } catch (error) {
      const duration = Math.round(performance.now() - started)
      row.dataset.state = 'failed'
      detail.textContent = (error && error.code ? error.code + ': ' : '') + (error && error.message ? error.message : String(error))
      time.textContent = duration + 'ms'
      failed += 1
      document.getElementById('failed').textContent = failed
      log(id + ' FAILED', errorPayload(error))
      throw error
    }
  }
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

  // The run spends most of its time with this tab in the background: every
  // approval pulls HandCash in front of the browser. The tab title is the one
  // surface that stays visible, so it carries the step and the outcome.
  const BASE_TITLE = document.title
  let elapsedTimer = null
  let runStartedAt = 0
  function setTitle(text) { document.title = text ? text + ' · HandCash Reference App' : BASE_TITLE }
  function stepIndex(id) { return STEP_DEFS.findIndex(def => def[0] === id) + 1 }
  function announceStep(id, message) {
    setTitle('▶ ' + stepIndex(id) + '/' + STEP_DEFS.length + ' ' + (message || STEP_DEFS[stepIndex(id) - 1][1]))
  }
  function paintElapsed() {
    document.getElementById('elapsed').textContent = ((performance.now() - runStartedAt) / 1000).toFixed(1) + 's'
  }
  function startElapsed() {
    runStartedAt = performance.now()
    paintElapsed()
    // Background tabs clamp timers to once a second, which is exactly the
    // cadence this needs; it never drives the flow itself.
    elapsedTimer = setInterval(paintElapsed, 1000)
  }
  function stopElapsed() {
    if (elapsedTimer) clearInterval(elapsedTimer)
    elapsedTimer = null
    paintElapsed()
  }
  window.addEventListener('beforeunload', event => {
    if (!running) return
    event.preventDefault()
    event.returnValue = ''
  })
  document.addEventListener('visibilitychange', () => {
    // Coming back mid-run: repaint the clock so it does not show the last
    // throttled tick.
    if (!document.hidden && running) paintElapsed()
  })

  // Start a request now, consume it later. A rejection is kept for the step
  // that awaits it instead of surfacing as an unhandled rejection meanwhile.
  function prefetch(work) {
    const promise = Promise.resolve().then(work)
    promise.catch(() => {})
    return promise
  }
  async function probe(base) {
    try {
      const response = await fetch(base + '/getVersion', {
        method:'POST', mode:'cors', cache:'no-store',
        headers:{'Content-Type':'application/json',originator:ORIGINATOR},
        body:'{}', signal:AbortSignal.timeout(1200)
      })
      const body = await response.json()
      return response.ok && typeof body.version === 'string'
    } catch { return false }
  }
  async function detectBridge() {
    if (bridgeBase) return bridgeBase
    for (let attempt = 0; attempt < 8; attempt++) {
      const results = await Promise.all([probe(HTTPS_BASE),probe(HTTP_BASE)])
      if (results[0]) return (bridgeBase = HTTPS_BASE)
      if (results[1]) return (bridgeBase = HTTP_BASE)
      await sleep(250)
    }
    throw Object.assign(new Error('Open and unlock HandCash, then try again.'), {code:'BRIDGE_UNAVAILABLE'})
  }
  async function walletCall(method, args) {
    if (!bridgeBase) await detectBridge()
    log('WALLET REQUEST ' + method, args || {})
    const response = await fetch(bridgeBase + '/' + method, {
      method:'POST', mode:'cors', cache:'no-store',
      headers:{'Content-Type':'application/json',originator:ORIGINATOR},
      body:JSON.stringify(args || {})
    })
    const text = await response.text()
    let body
    try { body = text ? JSON.parse(text) : {} } catch { body = {description:text} }
    log('WALLET RESPONSE ' + method + ' HTTP ' + response.status, body)
    if (!response.ok || body.status === 'error') {
      const error = new Error(body.description || body.error?.message || ('Wallet HTTP ' + response.status))
      error.code = body.code || body.error?.code
      throw error
    }
    return body
  }
  async function appCall(path, body) {
    log('WORKER REQUEST ' + path, body || {})
    const response = await fetch(path, body ? {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)
    } : {cache:'no-store'})
    const value = await response.json()
    log('WORKER RESPONSE ' + path + ' HTTP ' + response.status, value)
    if (!response.ok || value.status === 'error') {
      const error = new Error(value.description || ('Worker HTTP ' + response.status))
      error.code = value.code
      throw error
    }
    return value
  }
  function randomPart() {
    const bytes = crypto.getRandomValues(new Uint8Array(16))
    let raw = ''
    for (const byte of bytes) raw += String.fromCharCode(byte)
    return btoa(raw)
  }
  function randomNonce() {
    const bytes = crypto.getRandomValues(new Uint8Array(16))
    let raw = ''
    for (const byte of bytes) raw += String.fromCharCode(byte)
    return btoa(raw).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,'')
  }
  function bytesToHex(bytes) {
    let hex = ''
    for (const byte of bytes) hex += byte.toString(16).padStart(2,'0')
    return hex
  }
  function pushHex(bytes) {
    const size = bytes.length
    const body = bytesToHex(bytes)
    if (size <= 75) return size.toString(16).padStart(2,'0') + body
    if (size <= 255) return '4c' + size.toString(16).padStart(2,'0') + body
    if (size <= 65535) return '4d' + (size & 255).toString(16).padStart(2,'0') + (size >> 8).toString(16).padStart(2,'0') + body
    throw new Error('Inscription body is too large for this reference app')
  }
  function inscriptionScript(mime, body, p2pkh) {
    return '0063036f726451' + pushHex(enc.encode(mime)) + '00' + pushHex(body) + '68' + p2pkh
  }
  async function imageBytes(path) {
    const response = await fetch(path, {cache:'force-cache'})
    if (!response.ok) throw new Error('Could not load demo JPEG ' + path)
    return new Uint8Array(await response.arrayBuffer())
  }
  function outputCount(result) {
    if (Array.isArray(result && result.outputs)) return result.outputs.length
    if (Number.isFinite(Number(result && result.totalOutputs))) return Number(result.totalOutputs)
    return 0
  }
  function readPending() {
    try { return JSON.parse(localStorage.getItem(PENDING_KEY) || 'null') } catch { return null }
  }
  function holdPending(value) { localStorage.setItem(PENDING_KEY, JSON.stringify(value)) }
  function dropPending() { localStorage.removeItem(PENDING_KEY) }

  async function bounce(identityKey, configPromise, progress) {
    const config = await configPromise
    let pending = readPending()
    if (pending && pending.senderIdentityKey !== identityKey) {
      dropPending()
      pending = null
    }
    if (!pending) {
      progress('Deriving authenticated BRC-29 deposit')
      const derivationPrefix = randomPart()
      const derivationSuffix = randomPart()
      const keyID = derivationPrefix + ' ' + derivationSuffix
      // The Worker derives the deposit lock from the public identity key and
      // the prefix/suffix alone; the wallet's derivation is the conformance
      // check, not an input to prepare. Both round trips run at once.
      const [derived, prepared] = await Promise.all([
        walletCall('getPublicKey', {
          protocolID:BOUNCE_PROTOCOL,keyID,counterparty:config.identityKey
        }),
        appCall('/v1/tx-bounce/prepare', {
          senderIdentityKey:identityKey,derivationPrefix,derivationSuffix
        })
      ])
      assert(derived.publicKey, 'Wallet did not derive the BRC-29 deposit key')
      progress('Approve the 1,000-sat deposit')
      // Let the wallet broadcast. A BRC-29 payment is final the moment it is
      // signed, so there is nothing to withhold. Asking for noSend hands the
      // wallet a parent it cannot finalize (signAndProcess returns no
      // reference for processAction) and the toolbox only funds from
      // completed / unproven / sending parents, so the payer's own change
      // stops being selectable until something else heals it.
      //
      // The trustSelf option is left unset. The Worker needs the deposit's full
      // ancestry to chain the refund, and a 'known' reply carries txid-only stubs for every
      // parent the wallet trusts. The wallet then rebuilt those bodies from
      // storage — or the network — before it could answer. A complete BEEF
      // straight from the signer is the fast path.
      const payment = await walletCall('createAction', {
        description:'Reference app BRC-29 bounce',
        labels:['brc29','wallet-reference-demo'],
        outputs:[{
          lockingScript:prepared.lockingScript,
          satoshis:prepared.amountSats,
          outputDescription:'Reference app bounce deposit',
          customInstructions:JSON.stringify({derivationPrefix,derivationSuffix,payee:config.identityKey})
        }],
        options:{randomizeOutputs:false,signAndProcess:true,acceptDelayedBroadcast:true}
      })
      assert(payment.txid && Array.isArray(payment.tx), 'Wallet did not return Atomic BEEF')
      pending = {
        txid:payment.txid,atomicBeef:payment.tx,outputIndex:prepared.outputIndex,
        senderIdentityKey:identityKey,derivationPrefix,derivationSuffix
      }
      holdPending(pending)
    }
    progress('Worker is returning the exact deposit output')
    const refund = await appCall('/v1/tx-bounce/refund', pending)
    progress('Importing authenticated refund')
    await walletCall('internalizeAction', {
      tx:refund.atomicBeef,
      description:'Reference app BRC-29 refund',
      labels:['brc29','wallet-reference-demo','refund'],
      outputs:[{
        outputIndex:refund.outputIndex,
        protocol:'wallet payment',
        paymentRemittance:{
          derivationPrefix:refund.remittance.derivationPrefix,
          derivationSuffix:refund.remittance.derivationSuffix,
          senderIdentityKey:refund.senderIdentityKey
        }
      }]
    })
    dropPending()
    return refund
  }

  async function run() {
    if (running) return
    running = true
    passed = 0
    failed = 0
    document.getElementById('passed').textContent = '0'
    document.getElementById('failed').textContent = '0'
    document.getElementById('elapsed').textContent = '—'
    document.getElementById('log').textContent = ''
    for (const row of document.querySelectorAll('.step')) {
      row.dataset.state = 'idle'
      row.querySelector('small').textContent = 'Waiting'
      row.querySelector('.step-time').textContent = '—'
    }
    const button = document.getElementById('run')
    button.disabled = true
    button.textContent = 'Running…'
    startElapsed()
    let outcome = 'failed'
    // Everything the transaction steps need from the Worker and the asset
    // store is fetched while the earlier steps run, so the three signing
    // steps start at the wallet call — the only part that has to wait.
    const configPromise = prefetch(() => appCall('/v1/tx-bounce/config'))
    const bodiesPromise = prefetch(() => Promise.all([
      imageBytes('/wallet-demo-assets/robot.jpg'),
      imageBytes('/wallet-demo-assets/token.jpg')
    ]))
    let lockPromise = null
    try {
      const connected = await step('connect', async progress => {
        progress('Finding local BRC-100 bridge')
        await detectBridge()
        await walletCall('waitForAuthentication', {})
        const [version,network,height,balance,identity] = await Promise.all([
          walletCall('getVersion',{}),walletCall('getNetwork',{}),
          walletCall('getHeight',{}),walletCall('getBalance',{}),
          walletCall('getPublicKey',{identityKey:true})
        ])
        assert(identity.publicKey, 'Wallet did not return its identity key')
        const sats = Number(balance.satoshis ?? balance.balance ?? 0)
        document.getElementById('balance').textContent = sats.toLocaleString()
        return {
          identityKey:identity.publicKey,
          summary:'v' + version.version + ' · ' + (network.network || network) + ' · height ' + (height.height ?? height) + ' · ' + sats.toLocaleString() + ' sats'
        }
      })
      const identityKey = connected.identityKey
      lockPromise = prefetch(() => appCall('/v1/wallet-demo/p2pkh',{publicKey:identityKey}))

      await step('identity', async progress => {
        progress('Creating an origin-bound public proof')
        const issuedAt = Date.now()
        const challenge = JSON.stringify({
          domain:'handcash-wallet-identity-proof',version:1,origin:ORIGINATOR,
          nonce:randomNonce(),issuedAt,expiresAt:issuedAt + 120000,
          purpose:'Run the HandCash BRC-100 reference implementation'
        })
        const data = Array.from(enc.encode(challenge))
        const keyID = 'identity-proof:' + ORIGINATOR
        const signed = await walletCall('createSignature', {
          data,protocolID:PROOF_PROTOCOL,keyID,counterparty:'anyone'
        })
        assert(Array.isArray(signed.signature), 'Wallet returned no identity signature')
        progress('Verifying through BRC-3 with the signer identity')
        // Same counterparty as the signature, and forSelf: the signer was this
        // wallet. BRC-42 derives the signing key from (rootKey, counterparty);
        // verifying needs the public key of that same derived key, which is
        // what forSelf selects. Naming our own identity key as the counterparty
        // instead derives an unrelated key and always reports the signature as
        // invalid.
        const verified = await walletCall('verifySignature', {
          data,signature:signed.signature,protocolID:PROOF_PROTOCOL,keyID,
          counterparty:'anyone',forSelf:true
        })
        assert(verified.valid === true, 'Identity proof did not verify')
        return {summary:'Verified ' + identityKey.slice(0,16) + '…'}
      })

      await step('crypto', async progress => {
        const protocolID = [2,'wallet reference demo']
        const keyID = 'run-' + Date.now()
        const plaintext = Array.from(enc.encode('HandCash reference app round trip'))
        progress('Encrypting and decrypting')
        const encrypted = await walletCall('encrypt',{protocolID,keyID,plaintext})
        assert(Array.isArray(encrypted.ciphertext), 'Wallet returned no ciphertext')
        const decrypted = await walletCall('decrypt',{protocolID,keyID,ciphertext:encrypted.ciphertext})
        assert(dec.decode(new Uint8Array(decrypted.plaintext || [])) === 'HandCash reference app round trip','Decrypted bytes differ')
        progress('Creating and verifying HMAC')
        const made = await walletCall('createHmac',{protocolID,keyID,data:plaintext})
        const checked = await walletCall('verifyHmac',{protocolID,keyID,data:plaintext,hmac:made.hmac})
        assert(checked.valid === true, 'HMAC did not verify')
        return {summary:'Ciphertext ' + encrypted.ciphertext.length + ' bytes · HMAC verified'}
      })

      const before = await step('inventory-before', async progress => {
        progress('Reading BRC-165 and BRC-99 inventory scopes')
        const [items,tokens] = await Promise.all([
          walletCall('listOutputs',{basket:ITEM_SCOPE,includeTags:true,limit:100,offset:0}),
          walletCall('listOutputs',{basket:TOKEN_SCOPE,includeTags:true,limit:100,offset:0})
        ])
        return {items:outputCount(items),tokens:outputCount(tokens),summary:outputCount(items) + ' items · ' + outputCount(tokens) + ' token outputs'}
      })

      const refund = await step('bounce', async progress => {
        const value = await bounce(identityKey, configPromise, progress)
        return Object.assign(value,{summary:value.refundSatoshis.toLocaleString() + ' sats returned · fee ' + value.feeSatoshis})
      })
      assert(refund.refundTxid, 'Bounce returned no refund txid')

      const media = await step('mint-media', async progress => {
        const [lock, bodies] = await Promise.all([lockPromise, bodiesPromise])
        progress('Approve two 1Sat JPEG outputs')
        const result = await walletCall('createAction',{
          description:'Mint reference JPEG items',
          labels:['1sat','wallet-reference-demo','reference-media'],
          outputs:[
            {
              lockingScript:inscriptionScript('image/jpeg',bodies[0],lock.lockingScript),
              satoshis:1,outputDescription:'Reference Robot collectable',basket:'1sat',
              tags:['name:Reference Robot','app:wallet-reference-demo','issuer:' + identityKey]
            },
            {
              lockingScript:inscriptionScript('image/jpeg',bodies[1],lock.lockingScript),
              satoshis:1,outputDescription:'Reference Token icon',basket:'1sat',
              tags:['name:Reference Token Icon','app:wallet-reference-demo','issuer:' + identityKey]
            }
          ],
          options:{randomizeOutputs:false}
        })
        assert(result.txid, 'JPEG mint returned no txid')
        return {txid:result.txid,lock,summary:'Robot + token icon · ' + (bodies[0].length + bodies[1].length).toLocaleString() + ' JPEG bytes'}
      })

      const token = await step('mint-token', async progress => {
        const lock = media.lock
        progress('Approve the 1,000 REF deploy+mint')
        const icon = media.txid + '_1'
        const payload = {p:'bsv-20',op:'deploy+mint',sym:'REF',amt:'1000',dec:'0',icon}
        const body = enc.encode(JSON.stringify(payload))
        const result = await walletCall('createAction',{
          description:'Mint 1,000 REF reference tokens',
          labels:['bsv21','wallet-reference-demo','reference-token'],
          outputs:[{
            lockingScript:inscriptionScript('application/bsv-20',body,lock.lockingScript),
            satoshis:1,outputDescription:'1,000 REF tokens',basket:'bsv21',
            tags:['bsv21','op:deploy+mint','sym:REF','amt:1000','dec:0','icon:' + icon],
            customInstructions:JSON.stringify(payload)
          }],
          options:{randomizeOutputs:false}
        })
        assert(result.txid, 'Token mint returned no txid')
        return {txid:result.txid,summary:'1,000 REF · icon ' + icon.slice(0,12) + '…'}
      })

      await step('inventory-after', async progress => {
        progress('Reading baskets and labeled action history')
        const [items,tokens,actions,balance] = await Promise.all([
          walletCall('listOutputs',{basket:ITEM_SCOPE,includeTags:true,limit:100,offset:0}),
          walletCall('listOutputs',{basket:TOKEN_SCOPE,includeTags:true,limit:100,offset:0}),
          walletCall('listActions',{labels:['wallet-reference-demo'],labelQueryMode:'any',limit:20,offset:0}),
          walletCall('getBalance',{})
        ])
        const itemRows = Array.isArray(items.outputs) ? items.outputs : []
        const tokenRows = Array.isArray(tokens.outputs) ? tokens.outputs : []
        assert(itemRows.some(row => String(row.outpoint || '').startsWith(media.txid)), 'Minted JPEGs are missing from 1sat inventory')
        assert(tokenRows.some(row => String(row.outpoint || '').startsWith(token.txid)), 'Minted REF token is missing from bsv21 inventory')
        const itemCount = outputCount(items)
        const tokenCount = outputCount(tokens)
        assert(itemCount >= before.items + 2, 'Item inventory did not increase by two')
        assert(tokenCount >= before.tokens + 1, 'Token inventory did not increase')
        const sats = Number(balance.satoshis ?? balance.balance ?? 0)
        document.getElementById('balance').textContent = sats.toLocaleString()
        return {summary:itemCount + ' items · ' + tokenCount + ' token outputs · action history read'}
      })
      outcome = 'passed'
      button.textContent = 'Run again'
    } catch {
      button.textContent = 'Retry failed run'
    } finally {
      stopElapsed()
      const seconds = ((performance.now() - runStartedAt) / 1000).toFixed(1)
      setTitle(outcome === 'passed'
        ? '✓ ' + passed + '/' + STEP_DEFS.length + ' passed · ' + seconds + 's'
        : '✗ failed at step ' + (passed + 1) + ' · ' + seconds + 's')
      button.disabled = false
      running = false
    }
  }
  document.getElementById('run').addEventListener('click',run)
})()
</script>
</body>
</html>`
}

export function walletDemoAppResponse() {
  return new Response(walletDemoHtml(), {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store',
      'Content-Security-Policy': CSP,
      'Referrer-Policy': 'no-referrer',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    },
  })
}
