import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'
import vm from 'node:vm'
import { handleWalletDemo } from './walletDemo.js'
import { walletDemoAppResponse, walletDemoHtml } from './walletDemoApp.js'

const GENERATOR =
  '0279be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798'

test('wallet demo turns a public identity key into a standard P2PKH lock', async () => {
  const request = new Request('https://example.com/v1/wallet-demo/p2pkh', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ publicKey: GENERATOR }),
  })
  const response = await handleWalletDemo(
    request,
    {},
    new URL(request.url),
  )
  const body = await response.json()

  assert.equal(response.status, 200)
  assert.equal(body.status, 'success')
  assert.match(body.lockingScript, /^76a914[0-9a-f]{40}88ac$/)
})

test('wallet demo rejects malformed public keys', async () => {
  const request = new Request('https://example.com/v1/wallet-demo/p2pkh', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ publicKey: 'not-a-key' }),
  })
  const response = await handleWalletDemo(
    request,
    {},
    new URL(request.url),
  )
  const body = await response.json()

  assert.equal(response.status, 400)
  assert.equal(body.code, 'INVALID_WALLET_DEMO_PUBLIC_KEY')
})

test('wallet demo is a one-click readable BRC-100 reference flow', async () => {
  const response = walletDemoAppResponse()
  const html = await response.text()

  assert.match(html, /id="run"/)
  assert.match(html, /waitForAuthentication/)
  assert.match(html, /createSignature/)
  assert.match(html, /verifySignature/)
  assert.match(html, /createHmac/)
  assert.match(html, /verifyHmac/)
  assert.match(html, /listOutputs/)
  assert.match(html, /createAction/)
  assert.match(html, /internalizeAction/)
  // A reference implementation must model the payment path other apps copy:
  // BRC-29 broadcasts on signing, so it never holds a noSend parent.
  assert.doesNotMatch(html, /noSend\s*:/)
  assert.match(html, /application\/bsv-20/)
  assert.match(html, /image\/jpeg/)
  assert.match(html, /wallet-demo-assets\/robot\.jpg/)
  assert.match(html, /wallet-demo-assets\/token\.jpg/)
  assert.match(
    response.headers.get('Content-Security-Policy'),
    /connect-src 'self' https:\/\/127\.0\.0\.1:2121/,
  )
  assert.equal(response.headers.get('Cache-Control'), 'no-store')
  assert.equal(response.headers.get('X-Frame-Options'), 'DENY')
})

test('wallet demo verifies the identity proof with the key that signed it', () => {
  const html = walletDemoHtml()
  const sign = /createSignature',\s*\{([\s\S]*?)\}\)/.exec(html)
  const verify = /verifySignature',\s*\{([\s\S]*?)\}\)/.exec(html)
  assert.ok(sign && verify)

  // BRC-42 derives the signing key from (rootKey, counterparty). Verifying the
  // wallet's own signature therefore needs the same counterparty plus forSelf;
  // naming our identity key as the counterparty derives an unrelated key and
  // the SDK reports ERR_INVALID_SIGNATURE every time.
  assert.match(sign[1], /counterparty:'anyone'/)
  assert.match(verify[1], /counterparty:'anyone'/)
  assert.match(verify[1], /forSelf:true/)
  assert.doesNotMatch(verify[1], /counterparty:identityKey/)
})

test('wallet demo reads inventory through the permission scopes', () => {
  const html = walletDemoHtml()
  // `1sat` / `bsv21` are the wallet's internal storage baskets; an app asking
  // for them is refused with USE_P1SAT_SCOPE. Reads go through BRC-165/BRC-99.
  assert.match(html, /const ITEM_SCOPE = 'p 1sat all'/)
  assert.match(html, /const TOKEN_SCOPE = 'p bsv21 all'/)
  for (const read of html.matchAll(/listOutputs',\{basket:([^,]+),/g)) {
    assert.ok(
      read[1] === 'ITEM_SCOPE' || read[1] === 'TOKEN_SCOPE',
      `listOutputs must use a permission scope, got ${read[1]}`,
    )
  }
})

test('wallet demo asks the signer for a complete BEEF and prepares off the wallet path', () => {
  const html = walletDemoHtml()
  // A 'known' reply carries txid-only stubs the wallet must rebuild before
  // it can answer; the Worker needs the deposit's full ancestry anyway.
  assert.doesNotMatch(html, /trustSelf\s*:/)
  // Worker prepare and the wallet's derivation check are independent.
  assert.match(html, /Promise\.all\(\[\s*walletCall\('getPublicKey'/)
  // Assets and Worker helpers are in flight before the signing steps start.
  assert.match(html, /prefetch\(\(\) => appCall\('\/v1\/tx-bounce\/config'\)\)/)
  assert.match(html, /prefetch\(\(\) => appCall\('\/v1\/wallet-demo\/p2pkh'/)
  assert.match(html, /prefetch\(\(\) => Promise\.all\(\[\s*imageBytes/)
})

test('wallet demo reports progress where a background tab can show it', () => {
  const html = walletDemoHtml()
  assert.match(html, /document\.title = /)
  assert.match(html, /announceStep\(id\)/)
  assert.match(html, /addEventListener\('beforeunload'/)
  assert.match(html, /setInterval\(paintElapsed, 1000\)/)
})

test('wallet demo inscriptions use detail-resolution JPEGs', async () => {
  for (const name of ['robot.jpg', 'token.jpg']) {
    const body = await readFile(
      new URL(`../public/wallet-demo-assets/${name}`, import.meta.url),
    )
    let width = 0
    let height = 0
    for (let i = 2; i < body.length - 9;) {
      if (body[i] !== 0xff) {
        i += 1
        continue
      }
      const marker = body[i + 1]
      const length = body.readUInt16BE(i + 2)
      if ([0xc0, 0xc1, 0xc2].includes(marker)) {
        height = body.readUInt16BE(i + 5)
        width = body.readUInt16BE(i + 7)
        break
      }
      i += 2 + length
    }
    assert.ok(width >= 512 && height >= 512, `${name} is only ${width}×${height}`)
  }
})

test('wallet demo inline scripts parse as JavaScript', () => {
  const scripts = [
    ...walletDemoHtml().matchAll(/<script>([\s\S]*?)<\/script>/g),
  ].map((match) => match[1])
  assert.equal(scripts.length, 1)
  assert.doesNotThrow(() => new vm.Script(scripts[0]))
})
