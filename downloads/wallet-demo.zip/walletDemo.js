import { P2PKH, PublicKey } from '@bsv/sdk'

const PUBLIC_KEY = /^(02|03)[0-9a-f]{64}$/i

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'X-Content-Type-Options': 'nosniff',
    },
  })
}

/**
 * Public-key-only helper used by the browser reference app.
 *
 * HandCash owns and derives the private key. The Worker only projects the
 * public identity key into its ordinary mainnet P2PKH lock so the example can
 * build a standard 1Sat or BSV-21 output without shipping a crypto bundle.
 */
export async function handleWalletDemo(request, _env, url) {
  if (!url.pathname.startsWith('/v1/wallet-demo')) return null
  if (request.method === 'OPTIONS') return new Response(null, { status: 204 })
  if (request.method !== 'POST' || url.pathname !== '/v1/wallet-demo/p2pkh') {
    return json(
      {
        status: 'error',
        code: 'WALLET_DEMO_NOT_FOUND',
        description: 'Unknown wallet demo endpoint',
      },
      404,
    )
  }

  let body
  try {
    body = await request.json()
  } catch {
    return json(
      {
        status: 'error',
        code: 'INVALID_WALLET_DEMO_REQUEST',
        description: 'Expected a JSON body',
      },
      400,
    )
  }
  const publicKey = String(body?.publicKey ?? '').trim().toLowerCase()
  if (!PUBLIC_KEY.test(publicKey)) {
    return json(
      {
        status: 'error',
        code: 'INVALID_WALLET_DEMO_PUBLIC_KEY',
        description: 'Expected a compressed secp256k1 public key',
      },
      400,
    )
  }

  try {
    const key = PublicKey.fromString(publicKey)
    return json({
      status: 'success',
      publicKey,
      lockingScript: new P2PKH().lock(key.toAddress('mainnet')).toHex(),
    })
  } catch {
    return json(
      {
        status: 'error',
        code: 'INVALID_WALLET_DEMO_PUBLIC_KEY',
        description: 'The public key could not be decoded',
      },
      400,
    )
  }
}
