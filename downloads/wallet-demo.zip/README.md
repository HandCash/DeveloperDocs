# Wallet demo

One-click BRC-100 reference app. It connects to HandCash on this device, then runs identity, encryption, a 1,000-satoshi Transaction Bounce, two JPEG inscriptions, and a BSV-21 mint.

The live app is [Wallet demo](https://brc-cloud.bcryderman.workers.dev/wallet-demo).

| File | What it is |
|------|------------|
| `walletDemoApp.js` | The page. Wallet calls go to the local BRC-100 bridge (`127.0.0.1:2121` / `:3321`). |
| `walletDemo.js` | `POST /v1/wallet-demo/p2pkh` — turns the public identity key into its P2PKH lock. No private key reaches the Worker. |
| `walletDemo.test.js` | Page and helper checks. |
| `handcashLogo.js` | Lockup used in the page header. |
| `assets/robot.jpg`, `assets/token.jpg` | The two inscription bodies. The live app serves them at `/wallet-demo-assets/`. |

The bounce step calls the Transaction Bounce API (`/v1/tx-bounce/*`). That service key is not in this archive.
