import assert from 'node:assert/strict'
import { describe, it } from 'node:test'
import {
  P2PKH,
  PrivateKey,
  Transaction,
  UnlockingScript,
} from '@bsv/sdk'
import {
  buildBounceRefund,
  handleTxBounce,
} from './txBounce.js'
import { txBounceAppResponse } from './txBounceApp.js'

const service = PrivateKey.fromHex('1'.padStart(64, '0'))
const sender = PrivateKey.fromHex('2'.padStart(64, '0'))
const env = { TX_BOUNCE_PRIVATE_KEY: service.toWif() }
const prefix = 'deposit-prefix'
const suffix = 'deposit-suffix'
const invoice = `2-3241645161d8-${prefix} ${suffix}`

function depositFixture({ wrongKey = false } = {}) {
  const recipient = wrongKey
    ? PrivateKey.fromHex('3'.padStart(64, '0'))
    : service.deriveChild(sender.toPublicKey(), invoice)
  const tx = new Transaction()
  tx.addInput({
    sourceTXID: 'f'.repeat(64),
    sourceOutputIndex: 0,
    unlockingScript: new UnlockingScript(),
    sequence: 0xffffffff,
  })
  tx.addP2PKHOutput(recipient.toAddress('mainnet'), 1_000)
  return tx
}

function bodyFor(tx) {
  return {
    txid: tx.id('hex'),
    atomicBeef: tx.toAtomicBEEF(),
    outputIndex: 0,
    senderIdentityKey: sender.toPublicKey().toString(),
    derivationPrefix: prefix,
    derivationSuffix: suffix,
  }
}

function acceptingFetch(url) {
  if (
    String(url).endsWith('/txs') ||
    String(url).endsWith('/tx')
  ) {
    return Promise.resolve(new Response('', { status: 202 }))
  }
  return Promise.resolve(new Response('upstream unavailable', { status: 503 }))
}

describe('transaction bounce', () => {
  it('spends only the authenticated deposit and returns its value minus fee', async () => {
    const deposit = depositFixture()
    const result = await buildBounceRefund(bodyFor(deposit), env, acceptingFetch)

    assert.equal(result.status, 'ok')
    assert.equal(result.depositTxid, deposit.id('hex'))
    assert.equal(result.inputSatoshis, 1_000)
    assert.equal(result.refundSatoshis + result.feeSatoshis, 1_000)
    assert.ok(result.feeSatoshis > 0)
    assert.equal(result.provider, 'arcade-v2')
    assert.equal(typeof result.timings.totalMs, 'number')
    assert.equal(typeof result.timings.providerSubmitMs, 'number')

    const refund = Transaction.fromAtomicBEEF(result.atomicBeef)
    assert.equal(refund.id('hex'), result.refundTxid)
    assert.equal(refund.inputs[0].sourceTXID, deposit.id('hex'))
    assert.equal(refund.inputs[0].sourceOutputIndex, 0)

    const refundInvoice =
      `2-3241645161d8-${result.remittance.derivationPrefix} ` +
      result.remittance.derivationSuffix
    const expectedRecipient = sender
      .deriveChild(service.toPublicKey(), refundInvoice)
      .toAddress('mainnet')
    assert.equal(
      refund.outputs[0].lockingScript.toHex(),
      new P2PKH().lock(expectedRecipient).toHex(),
    )
  })

  it('produces the same refund transaction for an idempotent retry', async () => {
    const body = bodyFor(depositFixture())
    const first = await buildBounceRefund(body, env, acceptingFetch)
    const second = await buildBounceRefund(body, env, acceptingFetch)

    assert.equal(second.refundTxid, first.refundTxid)
    assert.deepEqual(second.remittance, first.remittance)
  })

  it('posts parent and child to Arcade together before explorers', async () => {
    const urls = []
    const fetchImpl = (url) => {
      urls.push(String(url))
      if (String(url).endsWith('/txs') || String(url).endsWith('/tx')) {
        return Promise.resolve(new Response('', { status: 202 }))
      }
      return Promise.resolve(new Response('ignored', { status: 503 }))
    }
    const result = await buildBounceRefund(bodyFor(depositFixture()), env, fetchImpl)
    assert.equal(result.provider, 'arcade-v2')
    const arcadePosts = urls.filter(
      (url) => url.includes('arcade-v2') && (url.endsWith('/txs') || url.endsWith('/tx')),
    )
    assert.equal(arcadePosts.length >= 1, true)
    const explorer = urls.findIndex(
      (url) => url.includes('bitails') || url.includes('whatsonchain'),
    )
    if (explorer >= 0) {
      const firstArcade = urls.findIndex(
        (url) => url.includes('arcade-v2') && (url.endsWith('/txs') || url.endsWith('/tx')),
      )
      assert.equal(firstArcade < explorer, true)
    }
  })

  it('falls back to parallel Arcade /tx posts instead of refund-only', async () => {
    const urls = []
    const fetchImpl = (url) => {
      urls.push(String(url))
      if (String(url).endsWith('/txs')) {
        return Promise.resolve(new Response('bad pack', { status: 400 }))
      }
      if (String(url).endsWith('/tx')) {
        return Promise.resolve(new Response('', { status: 202 }))
      }
      return Promise.resolve(new Response('ignored', { status: 503 }))
    }
    const result = await buildBounceRefund(bodyFor(depositFixture()), env, fetchImpl)
    assert.equal(result.provider, 'arcade-v2')
    assert.equal(urls.filter((url) => url.endsWith('/tx')).length >= 2, true)
  })

  it('returns the signed refund for wallet broadcast when cloud providers refuse it', async () => {
    const refusingFetch = async () =>
      new Response('missing inputs', { status: 400 })
    const result = await buildBounceRefund(
      bodyFor(depositFixture()),
      env,
      refusingFetch,
    )

    assert.equal(result.status, 'ok')
    assert.equal(result.provider, 'wallet-fallback')
    assert.equal(result.broadcastPending, true)
    assert.match(result.broadcastWarning, /Arcade HTTP 400|source transactions/)
    assert.doesNotThrow(() =>
      Transaction.fromAtomicBEEF(result.atomicBeef),
    )
  })

  it('refuses an output not derived for the service', async () => {
    await assert.rejects(
      buildBounceRefund(bodyFor(depositFixture({ wrongKey: true })), env, acceptingFetch),
      /not payable to this service/,
    )
  })

  it('serves config without exposing the private key', async () => {
    const url = new URL('https://example.com/v1/tx-bounce/config')
    const response = await handleTxBounce(new Request(url), env, url, acceptingFetch)
    const body = await response.json()

    assert.equal(response.status, 200)
    assert.equal(body.identityKey, service.toPublicKey().toString())
    assert.equal(body.amountSats, 1_000)
    assert.equal(JSON.stringify(body).includes(service.toWif()), false)
  })

  it('serializes Atomic BEEF as a BRC-100 byte array', async () => {
    const deposit = depositFixture()
    const url = new URL('https://example.com/v1/tx-bounce/refund')
    const response = await handleTxBounce(
      new Request(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(bodyFor(deposit)),
      }),
      env,
      url,
      acceptingFetch,
    )
    const body = await response.json()

    assert.equal(response.status, 200)
    assert.equal(Array.isArray(body.atomicBeef), true)
    assert.doesNotThrow(() =>
      Transaction.fromAtomicBEEF(body.atomicBeef),
    )
  })

  it('ships a one-button app with hardened response headers', async () => {
    const response = txBounceAppResponse()
    const html = await response.text()

    assert.match(html, /id="bounce"/)
    assert.match(html, /internalizeAction/)
    assert.match(html, /\/v1\/tx-bounce\/refund/)
    // The payer must not be left holding an unfinalizable parent: signAndProcess
    // returns no reference, so a noSend deposit can never be released and the
    // payer's own change stops being selectable for the next bounce.
    assert.doesNotMatch(html, /noSend\s*:/)
    assert.doesNotMatch(html, /walletCall\('processAction'/)
    assert.match(html, /Promise.all\(\[probe/)
    assert.match(html, /Parent and child go to Arcade together/)
    assert.match(html, /Retrying the existing deposit without sending another payment/)
    assert.match(html, /WALLET → APP/)
    assert.match(html, /APP WORKER/)
    assert.match(html, /Provider submit/)
    assert.match(html, /section-skeleton/)
    assert.match(html, /playClick/)
    assert.match(html, /paintBusy/)
    assert.match(html, /data-busy/)
    assert.match(response.headers.get('Content-Security-Policy'), /frame-ancestors 'none'/)
    assert.equal(response.headers.get('X-Frame-Options'), 'DENY')
  })
})
