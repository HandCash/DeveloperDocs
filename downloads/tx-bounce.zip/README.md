# Transaction Bounce

A one-button BRC-29 example. The user sends 1,000 satoshis to the app. The app spends that exact output back to the user, minus the network fee. The deposit and the refund go to Arcade together.

The live app is [Transaction Bounce](https://brc-cloud.bcryderman.workers.dev/tx-bounce).

| File | What it is |
|------|------------|
| `txBounceApp.js` | The page. Wallet calls go to the local BRC-100 bridge (`127.0.0.1:2121` / `:3321`). |
| `txBounce.js` | The Worker API: `GET /v1/tx-bounce/config`, `POST /v1/tx-bounce/prepare`, `POST /v1/tx-bounce/refund`. |
| `txBounce.test.js` | Refund construction and page checks. |
| `chainProviders.js` | Arcade, Bitails, and WhatsOnChain endpoints the refund path uses. |

The service identity is the Worker secret `TX_BOUNCE_PRIVATE_KEY`. It is not in this archive. The browser only ever receives the matching public key.

These files are the BRC-CLOUD implementation. They import `@bsv/sdk` and run inside that Worker; they are not a standalone `npm start` app.
