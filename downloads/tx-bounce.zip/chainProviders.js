/**
 * Shared upstream providers for HandCash Chain (headers + probe routes).
 * Each function returns a definitive answer or null so the caller can fall through.
 */

export const WOC_MAIN = 'https://api.whatsonchain.com/v1/bsv/main'
export const WOC_TEST = 'https://api.whatsonchain.com/v1/bsv/test'
export const BITAILS_MAIN = 'https://api.bitails.io'
export const BITAILS_TEST = 'https://test-api.bitails.io'
export const ARCADE_V2_MAIN = 'https://arcade-v2-us-1.bsvblockchain.tech'
export const ARCADE_V2_TEST = 'https://arcade-v2-testnet-us-1.bsvblockchain.tech'
/** GorillaPool BananaBlocks — WoC-compatible REST (2026). */
export const BANANABLOCKS_MAIN = 'https://bananablocks.com/api/v1/bsv/main'
export const BANANABLOCKS_TEST = 'https://bananablocks.com/api/v1/bsv/test'

const FETCH_TIMEOUT_MS = 4_000

/** @typedef {'arcade-v2' | 'bitails' | 'bananablocks' | 'whatsonchain'} ChainProviderId */

/** @typedef {{ id: ChainProviderId, chain: 'main' | 'test' }} ChainProvider */

export const CHAIN_PROVIDERS = /** @type {const} */ ([
  { id: 'arcade-v2', chain: 'main' },
  { id: 'bitails', chain: 'main' },
  { id: 'bananablocks', chain: 'main' },
  { id: 'whatsonchain', chain: 'main' },
  { id: 'arcade-v2', chain: 'test' },
  { id: 'bitails', chain: 'test' },
  { id: 'bananablocks', chain: 'test' },
  { id: 'whatsonchain', chain: 'test' },
])

function wocBase(chain) {
  return chain === 'main' ? WOC_MAIN : WOC_TEST
}

function bitailsBase(chain) {
  return chain === 'main' ? BITAILS_MAIN : BITAILS_TEST
}

function arcadeV2Base(chain) {
  return chain === 'main' ? ARCADE_V2_MAIN : ARCADE_V2_TEST
}

function bananablocksBase(chain) {
  return chain === 'main' ? BANANABLOCKS_MAIN : BANANABLOCKS_TEST
}

function wocCompatibleBase(id, chain) {
  if (id === 'whatsonchain') return wocBase(chain)
  if (id === 'bananablocks') return bananablocksBase(chain)
  return null
}

function providersForChain(chain) {
  return CHAIN_PROVIDERS.filter((p) => p.chain === chain)
}

export async function fetchJson(url, fetchImpl = fetch, timeoutMs = FETCH_TIMEOUT_MS) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const res = await fetchImpl(url, {
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    })
    // Error bodies carry the reason a provider failed ("Transaction not found"
    // vs an unspent 404), and callers need it to tell ignorance from evidence.
    const body = await res.json().catch(() => null)
    return { ok: res.ok, status: res.status, body }
  } catch {
    return { ok: false, status: 0, body: null }
  } finally {
    clearTimeout(timer)
  }
}

function hexTxid(value) {
  const raw = String(value ?? '').trim().toLowerCase()
  return /^[0-9a-f]{64}$/.test(raw) ? raw : null
}

/** A provider saying it has never heard of the transaction, not "unspent". */
function txUnknownBody(body) {
  if (!body || typeof body !== 'object') return false
  const text = String(body.error ?? body.message ?? '').toLowerCase()
  return text.includes('transaction not found') || text.includes('tx not found')
}

function classifyBitailsUtxoStatus(body) {
  if (!body || typeof body !== 'object') return 'unknown'
  const status = String(body.status ?? '').toLowerCase()
  if (status === 'unknown' || status === 'not found') return 'unknown'
  if (body.spent === true) return 'spent'
  if (body.spent === false) return 'unspent'
  return 'unknown'
}

function mapWocUnspentRows(rows) {
  return rows.map((r) => ({
    outpoint: `${r.tx_hash}.${r.tx_pos}`,
    txid: r.tx_hash,
    vout: r.tx_pos,
    satoshis: r.value,
    height: r.height,
  }))
}

/**
 * ARC statuses that mean the *network* has the transaction.
 *
 * Arcade also reports transactions it is merely holding. `PENDING_RETRY` is the
 * one that matters: a child whose parent was never accepted is parked for
 * rebroadcast — it is not on chain and may never be. Reporting those as "exists"
 * told wallets their send had confirmed and blocked every recovery action on the
 * row, because "on chain" is also the answer that forbids reclaiming its coins.
 */
const ARC_ON_CHAIN = new Set([
  'MINED',
  'CONFIRMED',
  'SEEN_ON_NETWORK',
  'ACCEPTED_BY_NETWORK',
])

/**
 * @param {string} txStatus
 * @returns {boolean | null} null = Arcade holds it but the chain has not seen
 *   it, so a chain provider must answer instead.
 */
export function arcadeStatusExists(txStatus) {
  const status = txStatus.trim().toUpperCase()
  if (!status) return null
  if (ARC_ON_CHAIN.has(status)) return true
  // REJECTED / parked are Arcade's opinion, not a chain answer. Fall through
  // so WhatsOnChain / Bitails can still report a tx Arcade never stored.
  return null
}

/**
 * @param {ChainProviderId} id
 * @param {'main' | 'test'} chain
 */
async function txExistsFromProvider(id, chain, txid, fetchImpl) {
  if (id === 'arcade-v2') {
    const res = await fetchJson(`${arcadeV2Base(chain)}/tx/${txid}`, fetchImpl)
    if (res.status === 404) return null
    if (res.body?.error && String(res.body.error).toLowerCase().includes('not found')) {
      return null
    }
    return arcadeStatusExists(String(res.body?.txStatus ?? ''))
  }
  if (id === 'bitails') {
    const res = await fetchJson(`${bitailsBase(chain)}/tx/${txid}/status`, fetchImpl)
    if (res.status === 404) return false
    if (res.ok) return true
    return null
  }
  const wocApi = wocCompatibleBase(id, chain)
  if (!wocApi) return null
  const res = await fetchJson(`${wocApi}/tx/hash/${txid}`, fetchImpl)
  if (res.status === 404) return false
  if (res.ok) return true
  return null
}

/**
 * @param {ChainProviderId} id
 * @param {'main' | 'test'} chain
 */
async function spentStatusFromProvider(id, chain, txid, vout, fetchImpl) {
  if (id === 'arcade-v2') {
    // Arcade `/tx/{txid}` reports whether the *source* transaction is known
    // (MINED / SEEN_*), not whether output `vout` has been spent. Using that as
    // spent-status marked every confirmed funding coin spent and wiped wallets
    // after market-list MissingInputs. Skip Arcade for outpoint spent checks.
    return null
  }
  if (id === 'bitails') {
    const res = await fetchJson(
      `${bitailsBase(chain)}/tx/${txid}/output/${vout}/status`,
      fetchImpl,
    )
    if (!res.ok) return null
    return classifyBitailsUtxoStatus(res.body)
  }
  const wocApi = wocCompatibleBase(id, chain)
  if (!wocApi) return null
  const res = await fetchJson(`${wocApi}/tx/${txid}/${vout}/spent`, fetchImpl)
  if (res.status === 404) {
    // WoC answers 404 for an unspent output, but a provider that does not know
    // the transaction answers 404 too. Only the first means unspent — treating
    // "Transaction not found" as unspent invents a live coin out of ignorance.
    return txUnknownBody(res.body) ? null : 'unspent'
  }
  if (!res.ok) return null
  const spendTxid = hexTxid(res.body?.txid)
  return spendTxid ? 'spent' : 'unknown'
}

/**
 * @param {ChainProviderId} id
 * @param {'main' | 'test'} chain
 */
async function addressUnspentFromProvider(id, chain, address, fetchImpl) {
  if (id === 'arcade-v2') {
    return null
  }
  if (id === 'bitails') {
    const res = await fetchJson(
      `${bitailsBase(chain)}/address/${encodeURIComponent(address)}/unspent`,
      fetchImpl,
    )
    if (!res.ok) return null
    const rows = Array.isArray(res.body?.unspent) ? res.body.unspent : []
    return rows.map((r) => ({
      outpoint: `${r.txid}.${r.vout}`,
      txid: r.txid,
      vout: r.vout,
      satoshis: r.satoshis,
      height: r.blockheight,
    }))
  }
  const wocApi = wocCompatibleBase(id, chain)
  if (!wocApi) return null
  const res = await fetchJson(
    `${wocApi}/address/${encodeURIComponent(address)}/unspent`,
    fetchImpl,
  )
  if (!res.ok) return null
  const rows = Array.isArray(res.body) ? res.body : []
  return mapWocUnspentRows(rows)
}

/** @returns {Promise<{ exists: boolean, source: ChainProviderId } | null>} */
export async function fetchTxExists(chain, txid, fetchImpl = fetch) {
  const id = hexTxid(txid)
  if (!id) return null
  let lastFalse = null
  for (const provider of providersForChain(chain)) {
    const exists = await txExistsFromProvider(provider.id, chain, id, fetchImpl)
    // `true` is chain evidence. `false` is one provider's absence — keep
    // walking so Arcade/Bitails 404 cannot hide a WhatsOnChain hit.
    if (exists === true) {
      return { exists: true, source: provider.id }
    }
    if (exists === false) lastFalse = provider.id
  }
  if (lastFalse) return { exists: false, source: lastFalse }
  return null
}

/** @returns {Promise<{ status: 'spent' | 'unspent' | 'unknown', source: ChainProviderId } | null>} */
export async function fetchSpentStatus(chain, txid, vout, fetchImpl = fetch) {
  const id = hexTxid(txid)
  const index = Number(vout)
  if (!id || !Number.isInteger(index) || index < 0) return null

  let bitailsUnknown = false
  for (const provider of providersForChain(chain)) {
    const status = await spentStatusFromProvider(
      provider.id,
      chain,
      id,
      index,
      fetchImpl,
    )
    if (status === 'spent' || status === 'unspent') {
      return { status, source: provider.id }
    }
    if (provider.id === 'bitails' && status === 'unknown') {
      bitailsUnknown = true
      continue
    }
    if (provider.id === 'whatsonchain' && status === 'unspent' && bitailsUnknown) {
      return { status: 'unknown', source: provider.id }
    }
  }
  return { status: 'unknown', source: providersForChain(chain).at(-1)?.id ?? 'whatsonchain' }
}

/** @returns {Promise<{ utxos: object[], source: ChainProviderId } | null>} */
export async function fetchAddressUnspent(chain, address, fetchImpl = fetch) {
  const trimmed = String(address ?? '').trim()
  if (!trimmed) return null
  for (const provider of providersForChain(chain)) {
    const utxos = await addressUnspentFromProvider(
      provider.id,
      chain,
      trimmed,
      fetchImpl,
    )
    if (utxos != null) {
      return { utxos, source: provider.id }
    }
  }
  return null
}

export async function fetchChainTip(chain, fetchImpl = fetch) {
  for (const provider of providersForChain(chain)) {
    if (provider.id === 'arcade-v2') {
      const res = await fetchJson(`${arcadeV2Base(chain)}/chaintracks/v2/tip`, fetchImpl)
      if (!res.ok || !res.body) continue
      const height = res.body.height
      const hash = res.body.hash
      const merkleroot = res.body.merkleRoot ?? res.body.merkleroot
      if (typeof height === 'number' && hash && merkleroot) {
        return { height, hash, merkleroot, source: provider.id }
      }
      continue
    }
    if (provider.id === 'bitails') {
      const res = await fetchJson(`${bitailsBase(chain)}/block/latest`, fetchImpl)
      if (!res.ok || !res.body) continue
      return {
        height: res.body.height,
        hash: res.body.hash,
        merkleroot: res.body.merkleroot ?? res.body.merkleRoot,
        source: provider.id,
      }
    }
    if (provider.id === 'bananablocks') {
      const res = await fetchJson(`${bananablocksBase(chain)}/chain/info`, fetchImpl)
      if (!res.ok || !res.body) continue
      const height = res.body.blocks
      const hash = res.body.bestblockhash ?? res.body.bestBlockHash
      if (typeof height === 'number' && hash) {
        return { height, hash, merkleroot: null, source: provider.id }
      }
      continue
    }
    const res = await fetchJson(`${wocBase(chain)}/chain/info`, fetchImpl)
    if (!res.ok || !res.body) continue
    const height = res.body.blocks
    const hash = res.body.bestblockhash ?? res.body.bestBlockHash
    if (typeof height === 'number' && hash) {
      return { height, hash, merkleroot: null, source: provider.id }
    }
  }
  return null
}

export async function fetchHeaderAtHeight(chain, height, fetchImpl = fetch) {
  if (!Number.isInteger(height) || height < 0) return null
  for (const provider of providersForChain(chain)) {
    if (provider.id === 'arcade-v2') {
      const res = await fetchJson(
        `${arcadeV2Base(chain)}/chaintracks/v2/header/height/${height}`,
        fetchImpl,
      )
      if (!res.ok || !res.body) continue
      return { header: res.body, source: provider.id }
    }
    if (provider.id === 'bitails') {
      const res = await fetchJson(`${bitailsBase(chain)}/block/height/${height}`, fetchImpl)
      if (!res.ok || !res.body) continue
      return { header: res.body, source: provider.id }
    }
    if (provider.id === 'bananablocks') {
      const res = await fetchJson(`${bananablocksBase(chain)}/block/${height}/header`, fetchImpl)
      if (!res.ok || !res.body) continue
      return { header: res.body, source: provider.id }
    }
    const res = await fetchJson(`${wocBase(chain)}/block/${height}/header`, fetchImpl)
    if (!res.ok || !res.body) continue
    return { header: res.body, source: provider.id }
  }
  return null
}

/** Lightweight upstream reachability for /v1/chain/health. */
export async function probeUpstream(fetchImpl = fetch) {
  const results = await Promise.all(
    CHAIN_PROVIDERS.map(async (provider) => {
      const url =
        provider.id === 'arcade-v2'
          ? `${arcadeV2Base(provider.chain)}/chaintracks/v2/height`
          : provider.id === 'bitails'
            ? `${bitailsBase(provider.chain)}/block/latest`
            : provider.id === 'bananablocks'
              ? `${bananablocksBase(provider.chain)}/chain/info`
              : `${wocBase(provider.chain)}/chain/info`
      const started = Date.now()
      const res = await fetchJson(url, fetchImpl, 3_000)
      return {
        id: provider.id,
        chain: provider.chain,
        ok: res.ok,
        latencyMs: Date.now() - started,
      }
    }),
  )
  return results
}
