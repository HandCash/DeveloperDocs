const TX_BOUNCE_CSP = [
  "default-src 'none'",
  "style-src 'unsafe-inline'",
  "script-src 'unsafe-inline'",
  "connect-src 'self' https://127.0.0.1:2121 http://127.0.0.1:3321",
  "img-src 'self' data:",
  "base-uri 'none'",
  "form-action 'none'",
  "frame-ancestors 'none'",
].join('; ')

function page() {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="color-scheme" content="dark">
  <title>Transaction Bounce · HandCash</title>
  <style>
    :root{--bg:#090b0a;--panel:#111512;--line:#263029;--text:#f4f7f5;--muted:#91a097;--green:#38f28c;--green2:#20bd6b;--red:#ff6b76;--amber:#ffcc66;font-family:Inter,ui-sans-serif,system-ui,sans-serif}
    *{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 50% -20%,#173524 0,transparent 50%),var(--bg);color:var(--text);display:grid;place-items:center;padding:24px}
    main{width:min(620px,100%);display:grid;gap:18px}.mark{width:56px;height:56px;margin:auto;border:1px solid #3d5948;border-radius:18px;display:grid;place-items:center;background:#122018;box-shadow:0 0 45px #1d8b5033}
    .mark svg{width:30px;color:var(--green)}h1{font-size:clamp(2rem,8vw,4rem);letter-spacing:-.055em;text-align:center;margin:4px 0 0;line-height:.95}header p{text-align:center;color:var(--muted);line-height:1.55;max-width:520px;margin:16px auto 0}
    .card{border:1px solid var(--line);background:color-mix(in srgb,var(--panel) 94%,transparent);border-radius:24px;padding:clamp(20px,5vw,34px);box-shadow:0 24px 80px #0008}
    .flow{display:grid;grid-template-columns:1fr auto 1fr;gap:12px;align-items:center;margin-bottom:28px}.value{padding:15px;border:1px solid var(--line);border-radius:14px;background:#0c100d}.value small{display:block;color:var(--muted);font-size:.72rem;text-transform:uppercase;letter-spacing:.11em}.value strong{display:block;margin-top:5px;font-size:1.15rem}.arrow{color:var(--green);font-size:1.4rem}
    button{width:100%;border:0;border-radius:15px;background:linear-gradient(135deg,var(--green),var(--green2));color:#041008;font:800 1rem inherit;padding:18px 24px;cursor:pointer;box-shadow:0 10px 35px #20bd6b33;transition:.12s transform,.12s opacity,box-shadow .12s}button:hover:not(:disabled){transform:translateY(-1px)}button:active:not(:disabled){transform:translateY(1px) scale(.985);box-shadow:0 4px 16px #20bd6b22}button:disabled{cursor:wait;opacity:.72}button.secondary{margin-top:10px;background:none;border:1px solid var(--line);color:var(--muted);font-weight:600;font-size:.82rem;padding:12px 18px;box-shadow:none}button.secondary:hover:not(:disabled){color:#e7efe9;border-color:#3a473f}
    .card[data-busy=true] .flow .value strong{color:transparent;background:linear-gradient(90deg,#152018 20%,#2a3b30 50%,#152018 80%);background-size:200% 100%;animation:shimmer 1.05s linear infinite;border-radius:6px;min-height:1.15em}
    .card[data-busy=true] .skeleton{display:grid;gap:8px;margin-top:14px}.skeleton{display:none}.card[data-busy=true] .skeleton{display:grid}.skel{height:10px;border-radius:999px;background:linear-gradient(90deg,#152018 20%,#2a3b30 50%,#152018 80%);background-size:200% 100%;animation:shimmer 1.05s linear infinite}.skel.w60{width:60%}.skel.w85{width:85%}.skel.w40{width:40%}
    .status{margin:18px 0 0;border-top:1px solid var(--line);padding-top:18px;display:flex;gap:12px;align-items:flex-start}.dot{width:9px;height:9px;border-radius:50%;background:var(--muted);margin-top:5px;box-shadow:0 0 0 5px #91a09718;flex:none}.status[data-tone=busy] .dot{background:var(--amber);box-shadow:0 0 0 5px #ffcc6618;animation:pulse 1s infinite}.status[data-tone=ok] .dot{background:var(--green);box-shadow:0 0 0 5px #38f28c18}.status[data-tone=error] .dot{background:var(--red);box-shadow:0 0 0 5px #ff6b7618}.status strong{display:block;font-size:.9rem}.status span{display:block;color:var(--muted);font-size:.78rem;line-height:1.5;margin-top:3px;word-break:break-word}
    .receipt{display:none;margin-top:16px;padding:14px;border-radius:12px;background:#090c0a;border:1px solid var(--line);font:12px/1.7 ui-monospace,SFMono-Regular,monospace;color:var(--muted);white-space:pre-wrap;word-break:break-all}.receipt[data-visible=true]{display:block}footer{text-align:center;color:#66736b;font-size:.72rem;line-height:1.5}
    @keyframes pulse{50%{opacity:.4}}@keyframes shimmer{0%{background-position:200% 0}100%{background-position:-200% 0}}@media(max-width:480px){body{padding:14px}.flow{grid-template-columns:1fr}.arrow{transform:rotate(90deg);text-align:center}.card{border-radius:20px}}
  </style>
</head>
<body>
<main>
  <header>
    <div class="mark" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 7h-9a5 5 0 0 0-5 5v1"/><path d="m17 4 3 3-3 3"/><path d="M4 17h9a5 5 0 0 0 5-5v-1"/><path d="m7 20-3-3 3-3"/></svg></div>
    <h1>Transaction Bounce</h1>
    <p>Send one BRC-29 payment to this app. It immediately spends that exact output back to you, minus only the network fee. Parent and child go to Arcade together.</p>
  </header>
  <section class="card">
    <div class="flow" aria-label="Bounce transaction flow">
      <div class="value"><small>You send</small><strong id="send-value">1,000 sats</strong></div>
      <div class="arrow" aria-hidden="true">→</div>
      <div class="value"><small>You receive</small><strong>Amount − fee</strong></div>
    </div>
    <button id="bounce" type="button">Bounce 1,000 sats</button>
    <button id="discard" class="secondary" type="button" hidden>Discard the held deposit</button>
    <div class="status" id="status" data-tone="idle" role="status" aria-live="polite">
      <i class="dot"></i><div><strong id="status-title">Ready</strong><span id="status-detail">Open and unlock HandCash, then press the button.</span></div>
    </div>
    <div class="skeleton" id="section-skeleton" aria-hidden="true"><i class="skel w85"></i><i class="skel w60"></i><i class="skel w40"></i></div>
    <div class="receipt" id="receipt"></div>
  </section>
  <footer>No pooled funds. The refund spends only your new deposit output. Repeating the request produces the same refund transaction.</footer>
</main>
<script>
(() => {
  'use strict'
  const HTTPS_BASE = 'https://127.0.0.1:2121'
  const HTTP_BASE = 'http://127.0.0.1:3321'
  const ORIGINATOR = location.host
  const PROTOCOL_ID = [2, '3241645161d8']
  const PENDING_KEY = 'handcash.txBounce.pending.v1'
  let bridgeBase = null
  let config = null
  const card = document.querySelector('section.card')
  const button = document.getElementById('bounce')
  const discard = document.getElementById('discard')
  const status = document.getElementById('status')
  const title = document.getElementById('status-title')
  const detail = document.getElementById('status-detail')
  const receipt = document.getElementById('receipt')
  let running = false
  let clickSoundPlayed = false
  let audioCtx = null

  const setStatus = (tone, heading, message) => {
    status.dataset.tone = tone
    title.textContent = heading
    detail.textContent = message
  }
  const playClick = () => {
    try {
      const AC = window.AudioContext || window.webkitAudioContext
      if (!AC) return
      audioCtx ||= new AC()
      if (audioCtx.state === 'suspended') audioCtx.resume()
      const t = audioCtx.currentTime
      const osc = audioCtx.createOscillator()
      const gain = audioCtx.createGain()
      osc.type = 'triangle'
      osc.frequency.setValueAtTime(980, t)
      osc.frequency.exponentialRampToValueAtTime(420, t + 0.05)
      gain.gain.setValueAtTime(0.0001, t)
      gain.gain.exponentialRampToValueAtTime(0.07, t + 0.006)
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.06)
      osc.connect(gain)
      gain.connect(audioCtx.destination)
      osc.start(t)
      osc.stop(t + 0.07)
    } catch {}
  }
  const paintBusy = async (heading, message) => {
    card.dataset.busy = 'true'
    button.disabled = true
    receipt.dataset.visible = 'false'
    setStatus('busy', heading, message)
    // Flush paint so skeleton + status show before slow wallet/network work.
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))
  }
  const clearBusy = () => {
    card.dataset.busy = 'false'
  }
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
  const randomPart = () => {
    const bytes = crypto.getRandomValues(new Uint8Array(16))
    let raw = ''
    for (const byte of bytes) raw += String.fromCharCode(byte)
    return btoa(raw)
  }
  async function probe(base) {
    try {
      const response = await fetch(base + '/getVersion', {
        method:'POST', mode:'cors', cache:'no-store',
        headers:{'Content-Type':'application/json',originator:ORIGINATOR},
        body:'{}', signal:AbortSignal.timeout(800)
      })
      return response.ok
    } catch { return false }
  }
  async function detectBridge() {
    if (bridgeBase) return bridgeBase
    for (let attempt = 0; attempt < 6; attempt++) {
      const [httpsOk, httpOk] = await Promise.all([probe(HTTPS_BASE), probe(HTTP_BASE)])
      if (httpsOk) return (bridgeBase = HTTPS_BASE)
      if (httpOk) return (bridgeBase = HTTP_BASE)
      await sleep(200)
    }
    throw Object.assign(new Error('Open and unlock HandCash, then try again.'), {code:'BRIDGE_UNAVAILABLE'})
  }
  async function walletCall(method, args) {
    if (!bridgeBase) await detectBridge()
    const response = await fetch(bridgeBase + '/' + method, {
      method:'POST', mode:'cors', cache:'no-store',
      headers:{'Content-Type':'application/json',originator:ORIGINATOR},
      body:JSON.stringify(args || {})
    })
    const text = await response.text()
    let body
    try { body = text ? JSON.parse(text) : {} } catch { body = {description:text} }
    if (!response.ok || body.status === 'error') {
      const error = new Error(body.description || body.error?.message || ('Wallet HTTP ' + response.status))
      error.code = body.code || body.error?.code
      throw error
    }
    return body
  }
  // A deposit is signed before the refund is asked for, so it must outlive a
  // reload. That made any failure after signing permanent: every later press
  // replayed the same held deposit and failed the same way, with no way out.
  function readPending() {
    try { return JSON.parse(localStorage.getItem(PENDING_KEY) || 'null') } catch { return null }
  }
  function syncDiscard() {
    discard.hidden = !readPending()
  }
  function holdPending(value) {
    localStorage.setItem(PENDING_KEY, JSON.stringify(value))
    syncDiscard()
  }
  function dropPending() {
    localStorage.removeItem(PENDING_KEY)
    syncDiscard()
  }
  async function appCall(path, body) {
    const response = await fetch(path, body ? {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(body)
    } : {cache:'no-store'})
    const value = await response.json()
    if (!response.ok || value.status === 'error') {
      const error = new Error(value.description || ('App HTTP ' + response.status))
      error.code = value.code
      throw error
    }
    return value
  }
  async function bounce() {
    if (running) return
    running = true
    if (!clickSoundPlayed) playClick()
    clickSoundPlayed = false
    const started = performance.now()
    const timings = {}
    try {
      const connectStarted = performance.now()
      await paintBusy('Connecting', 'Finding your local HandCash wallet…')
      config ||= await appCall('/v1/tx-bounce/config')
      await walletCall('waitForAuthentication', {})
      const identity = await walletCall('getPublicKey', {identityKey:true})
      const senderIdentityKey = identity.publicKey
      if (!senderIdentityKey) throw new Error('Wallet did not return an identity key')
      timings.connectMs = performance.now() - connectStarted

      let pending = readPending()
      if (pending && pending.senderIdentityKey !== senderIdentityKey) {
        // A deposit this wallet cannot claim is dead weight, not a reason to
        // refuse forever. Drop it and bounce a fresh one.
        dropPending()
        pending = null
      }

      if (!pending) {
        const prepareStarted = performance.now()
        const derivationPrefix = randomPart()
        const derivationSuffix = randomPart()
        const keyID = derivationPrefix + ' ' + derivationSuffix
        setStatus('busy', 'Preparing deposit', 'Deriving a private BRC-29 payment output…')
        const derived = await walletCall('getPublicKey', {
          protocolID:PROTOCOL_ID,
          keyID,
          counterparty:config.identityKey
        })
        if (!derived.publicKey) throw new Error('Wallet did not derive the deposit key')
        const prepared = await appCall('/v1/tx-bounce/prepare', {
          senderIdentityKey, derivationPrefix, derivationSuffix
        })
        timings.prepareMs = performance.now() - prepareStarted

        const depositStarted = performance.now()
        setStatus('busy', 'Approve payment', 'HandCash is signing and broadcasting the deposit.')
        // A BRC-29 payment broadcasts immediately. Asking for noSend instead
        // leaves the wallet holding a parent it cannot finalize — there is no
        // reference to pass to processAction after signAndProcess — and the
        // toolbox only funds from completed / unproven / sending parents, so
        // the payer's whole managed change went missing until the next bounce
        // reported "insufficient funds" on a funded wallet.
        const payment = await walletCall('createAction', {
          description:'Transaction Bounce test payment',
          labels:['brc29','tx-bounce'],
          outputs:[{
            lockingScript:prepared.lockingScript,
            satoshis:prepared.amountSats,
            outputDescription:'Transaction Bounce deposit',
            customInstructions:JSON.stringify({
              derivationPrefix, derivationSuffix, payee:config.identityKey
            })
          }],
          options:{
            randomizeOutputs:false,
            signAndProcess:true,
            acceptDelayedBroadcast:true,
            trustSelf:'known'
          }
        })
        if (!payment.txid || !Array.isArray(payment.tx)) {
          throw new Error('Wallet signed the payment without returning Atomic BEEF')
        }
        timings.depositMs = performance.now() - depositStarted
        pending = {
          txid:payment.txid,
          atomicBeef:payment.tx,
          outputIndex:prepared.outputIndex,
          senderIdentityKey,
          derivationPrefix,
          derivationSuffix
        }
        holdPending(pending)
      } else {
        setStatus('busy', 'Resuming refund', 'Retrying the existing deposit without sending another payment…')
      }

      const refundStarted = performance.now()
      setStatus('busy', 'Returning payment', 'Signing the child and posting both transactions to Arcade together…')
      let refund
      try {
        refund = await appCall('/v1/tx-bounce/refund', pending)
      } catch (error) {
        // Bytes the server can never accept — a deposit signed by an older
        // wallet build, or one whose inputs have since moved. Replaying it
        // fails identically forever, so let it go and say so.
        if (error && error.code === 'INVALID_TX_BOUNCE_REQUEST') {
          dropPending()
          error.message =
            (error.message || 'The held deposit could not be used') +
            ' — discarded. Press the button to bounce a fresh one.'
        }
        throw error
      }
      timings.refundRoundTripMs = performance.now() - refundStarted

      const ingestStarted = performance.now()
      setStatus(
        'busy',
        'Crediting wallet',
        refund.broadcastPending
          ? 'HandCash is importing the signed refund. Arcade already has the chain when the package landed.'
          : 'HandCash is importing the authenticated refund from the app message.'
      )
      await walletCall('internalizeAction', {
        tx:refund.atomicBeef,
        description:'Transaction Bounce refund',
        labels:['brc29','tx-bounce','refund'],
        outputs:[{
          outputIndex:refund.outputIndex,
          protocol:'wallet payment',
          paymentRemittance:{
            derivationPrefix:refund.remittance.derivationPrefix,
            derivationSuffix:refund.remittance.derivationSuffix,
            senderIdentityKey:refund.senderIdentityKey
          }
        }]
      })
      timings.ingestMs = performance.now() - ingestStarted
      dropPending()

      const elapsed = Math.round(performance.now() - started)
      const worker = refund.timings || {}
      const ms = value =>
        Number.isFinite(Number(value)) ? Math.round(Number(value)) + ' ms' : '—'
      const walletOutboundMs =
        Number(timings.connectMs || 0) +
        Number(timings.prepareMs || 0) +
        Number(timings.depositMs || 0)
      setStatus('ok', 'Bounce complete', refund.refundSatoshis.toLocaleString() + ' sats returned in ' + elapsed + ' ms.')
      receipt.textContent = [
        'TOTAL             ' + ms(elapsed),
        '',
        'WALLET → APP      ' + ms(walletOutboundMs),
        '  Connect/auth    ' + ms(timings.connectMs),
        '  Derive/prepare  ' + ms(timings.prepareMs),
        '  Sign deposit    ' + ms(timings.depositMs),
        '',
        'APP WORKER        ' + ms(worker.totalMs),
        '  Parse deposit   ' + ms(worker.parseDepositMs),
        '  Validate        ' + ms(worker.validateDepositMs),
        '  Derive refund   ' + ms(worker.deriveRefundMs),
        '  Build/sign      ' + ms(worker.buildAndSignMs),
        '  Provider submit ' + ms(worker.providerSubmitMs) + ' · ' + refund.provider,
        '  Network RTT     ' + ms(timings.refundRoundTripMs),
        '',
        'APP → WALLET      ' + ms(timings.ingestMs),
        '',
        'Deposit  ' + pending.txid,
        'Refund   ' + refund.refundTxid,
        'Fee      ' + refund.feeSatoshis + ' sats'
      ].join('\\n')
      receipt.dataset.visible = 'true'
      button.textContent = 'Bounce again'
    } catch (error) {
      const code = error && error.code ? error.code + ': ' : ''
      setStatus('error', 'Bounce stopped', code + (error?.message || String(error)))
      button.textContent = 'Try again'
    } finally {
      clearBusy()
      button.disabled = false
      running = false
    }
  }
  // Sound on pointerdown so feedback beats a slow click→handler→paint chain.
  button.addEventListener('pointerdown', event => {
    if (event.button !== 0 || button.disabled || running) return
    clickSoundPlayed = true
    playClick()
  })
  button.addEventListener('click', bounce)
  discard.addEventListener('click', () => {
    if (running) return
    dropPending()
    receipt.dataset.visible = 'false'
    setStatus('idle', 'Held deposit discarded', 'Press the button to bounce a fresh one.')
    if (config) button.textContent = 'Bounce ' + config.amountSats.toLocaleString() + ' sats'
  })
  syncDiscard()
  if (readPending()) {
    setStatus(
      'idle',
      'A deposit is held',
      'The last bounce stopped after signing. Press the button to retry it, or discard it below.'
    )
  }
  appCall('/v1/tx-bounce/config').then(value => {
    config = value
    document.getElementById('send-value').textContent = value.amountSats.toLocaleString() + ' sats'
    button.textContent = 'Bounce ' + value.amountSats.toLocaleString() + ' sats'
  }).catch(error => setStatus('error', 'Service unavailable', error.message))
})()
</script>
</body>
</html>`
}

export function txBounceAppResponse() {
  return new Response(page(), {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-store',
      'Content-Security-Policy': TX_BOUNCE_CSP,
      'Referrer-Policy': 'no-referrer',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY',
    },
  })
}
