import {
  P2PKH,
  PrivateKey,
  PublicKey,
  SatoshisPerKilobyte,
  Transaction,
} from '@bsv/sdk'
import {
  ARCADE_V2_MAIN,
  BITAILS_MAIN,
  WOC_MAIN,
} from './chainProviders.js'

export const TX_BOUNCE_PROTOCOL_ID = [2, '3241645161d8']
export const TX_BOUNCE_AMOUNT_SATS = 1_000
export const TX_BOUNCE_FEE_RATE = 100
const MAX_ATOMIC_BEEF_BYTES = 1_000_000
const MAX_BODY_BYTES = 1_400_000
const DERIVATION_PART = /^[A-Za-z0-9+/_=-]{1,128}$/
const IDENTITY_KEY = /^(02|03)[0-9a-f]{64}$/i

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'X-Content-Type-Options': 'nosniff',
    },
  })
}

function serviceKey(env) {
  const wif = String(env?.TX_BOUNCE_PRIVATE_KEY || '').trim()
  if (!wif) throw new Error('TX_BOUNCE_PRIVATE_KEY is not configured')
  return PrivateKey.fromWif(wif)
}

function invoiceNumber(prefix, suffix) {
  if (!DERIVATION_PART.test(prefix) || !DERIVATION_PART.test(suffix)) {
    throw new Error('Invalid BRC-29 derivation values')
  }
  return `2-${TX_BOUNCE_PROTOCOL_ID[1]}-${prefix} ${suffix}`
}

function senderKey(value) {
  const normalized = String(value || '').trim().toLowerCase()
  if (!IDENTITY_KEY.test(normalized)) throw new Error('Invalid sender identity key')
  return PublicKey.fromString(normalized)
}

function expectedDeposit(env, senderIdentityKey, prefix, suffix) {
  const root = serviceKey(env)
  const child = root.deriveChild(
    senderKey(senderIdentityKey),
    invoiceNumber(prefix, suffix),
  )
  return {
    root,
    child,
    lockingScript: new P2PKH().lock(child.toAddress('mainnet')),
  }
}

async function deterministicRefundDerivation(txid, outputIndex) {
  const digest = new Uint8Array(
    await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(`handcash-tx-bounce:${txid}.${outputIndex}`),
    ),
  )
  const encode = (bytes) => {
    let raw = ''
    for (const byte of bytes) raw += String.fromCharCode(byte)
    return btoa(raw)
  }
  return {
    derivationPrefix: encode(digest.slice(0, 16)),
    derivationSuffix: encode(digest.slice(16)),
  }
}

function parseAtomicBeef(value) {
  if (
    !Array.isArray(value) ||
    value.length === 0 ||
    value.length > MAX_ATOMIC_BEEF_BYTES ||
    !value.every((byte) => Number.isInteger(byte) && byte >= 0 && byte <= 255)
  ) {
    throw new Error('Invalid Atomic BEEF')
  }
  return Transaction.fromAtomicBEEF(Uint8Array.from(value))
}

function concatBytes(...chunks) {
  const size = chunks.reduce((sum, chunk) => sum + chunk.length, 0)
  const result = new Uint8Array(size)
  let offset = 0
  for (const chunk of chunks) {
    result.set(chunk, offset)
    offset += chunk.length
  }
  return result
}

async function responseDetail(response) {
  try {
    return (await response.text()).replace(/\s+/g, ' ').slice(0, 300)
  } catch {
    return ''
  }
}

/** Hot path for chained bounce — do not wait on explorers. */
const ARCADE_HOT_MS = 2_500
const SECONDARY_MS = 8_000

function txWireBytes(tx) {
  try {
    return tx.toEFUint8Array()
  } catch {
    return tx.toAtomicBEEF()
  }
}

async function postArcade(path, body, fetchImpl, timeoutMs) {
  const response = await fetchImpl(`${ARCADE_V2_MAIN}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/octet-stream' },
    body,
    signal: AbortSignal.timeout(timeoutMs),
  })
  if (!response.ok && response.status !== 202) {
    throw new Error(
      `Arcade HTTP ${response.status}: ${await responseDetail(response)}`,
    )
  }
  return { provider: 'arcade-v2', status: response.status }
}

/**
 * Parent + child in one Arcade round. Refund-only is unsafe when the deposit
 * is still local (BRC-100 createAction noSend).
 */
async function submitArcadeChained(deposit, refund, fetchImpl) {
  let packedError
  try {
    const body = concatBytes(deposit.toEFUint8Array(), refund.toEFUint8Array())
    return await postArcade('/txs', body, fetchImpl, ARCADE_HOT_MS)
  } catch (error) {
    packedError = error
  }
  try {
    const [receipt] = await Promise.all([
      postArcade('/tx', txWireBytes(deposit), fetchImpl, ARCADE_HOT_MS),
      postArcade('/tx', txWireBytes(refund), fetchImpl, ARCADE_HOT_MS),
    ])
    return receipt
  } catch (parallel) {
    throw packedError && /Arcade HTTP/.test(String(packedError.message || packedError))
      ? packedError
      : parallel
  }
}

async function submitBitailsPackage(deposit, refund, fetchImpl) {
  const response = await fetchImpl(`${BITAILS_MAIN}/tx/broadcast/multi`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ raws: [deposit.toHex(), refund.toHex()] }),
    signal: AbortSignal.timeout(SECONDARY_MS),
  })
  const text = await response.text()
  if (!response.ok) {
    throw new Error(
      `Bitails HTTP ${response.status}: ${text.replace(/\s+/g, ' ').slice(0, 300)}`,
    )
  }
  let rows
  try {
    rows = JSON.parse(text)
  } catch {
    throw new Error('Bitails returned invalid JSON')
  }
  const refundTxid = refund.id('hex')
  const result = Array.isArray(rows)
    ? rows.find((row) => String(row?.txid || '').toLowerCase() === refundTxid)
    : null
  const errorMessage = String(result?.error?.message || '')
  if (
    !result ||
    (result.error &&
      !/already|known|mempool|block chain/i.test(errorMessage))
  ) {
    throw new Error(
      `Bitails rejected refund: ${errorMessage || text.replace(/\s+/g, ' ').slice(0, 300)}`,
    )
  }
  return { provider: 'bitails', status: response.status }
}

async function submitWhatsOnChain(refund, fetchImpl) {
  const response = await fetchImpl(`${WOC_MAIN}/tx/raw`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ txhex: refund.toHex() }),
    signal: AbortSignal.timeout(SECONDARY_MS),
  })
  if (!response.ok) {
    throw new Error(
      `WhatsOnChain HTTP ${response.status}: ${await responseDetail(response)}`,
    )
  }
  return { provider: 'whatsonchain', status: response.status }
}

function propagateSecondary(deposit, refund, fetchImpl, ctx) {
  const work = Promise.any([
    submitBitailsPackage(deposit, refund, fetchImpl),
    submitWhatsOnChain(refund, fetchImpl),
  ]).catch((error) => {
    console.warn(
      '[tx-bounce] secondary propagation skipped',
      error instanceof Error ? error.message : String(error),
    )
  })
  if (ctx && typeof ctx.waitUntil === 'function') ctx.waitUntil(work)
  else void work
}

async function submitChainedPackage(deposit, refund, fetchImpl, ctx) {
  const receipt = await submitArcadeChained(deposit, refund, fetchImpl)
  propagateSecondary(deposit, refund, fetchImpl, ctx)
  return receipt
}

async function requestBody(request) {
  const declared = Number(request.headers.get('Content-Length') || 0)
  if (declared > MAX_BODY_BYTES) throw new Error('Request body too large')
  const text = await request.text()
  if (text.length > MAX_BODY_BYTES) throw new Error('Request body too large')
  return JSON.parse(text)
}

export async function buildBounceRefund(body, env, fetchImpl = fetch, ctx) {
  const startedAt = Date.now()
  const senderIdentityKey = String(body?.senderIdentityKey || '').trim().toLowerCase()
  const prefix = String(body?.derivationPrefix || '').trim()
  const suffix = String(body?.derivationSuffix || '').trim()
  const outputIndex = Number(body?.outputIndex ?? 0)
  if (!Number.isInteger(outputIndex) || outputIndex < 0) {
    throw new Error('Invalid deposit output index')
  }

  const deposit = parseAtomicBeef(body?.atomicBeef)
  const depositTxid = deposit.id('hex')
  const parsedAt = Date.now()
  if (
    body?.txid &&
    String(body.txid).trim().toLowerCase() !== depositTxid
  ) {
    throw new Error('Deposit txid does not match Atomic BEEF')
  }

  const expected = expectedDeposit(
    env,
    senderIdentityKey,
    prefix,
    suffix,
  )
  const depositOutput = deposit.outputs[outputIndex]
  if (
    !depositOutput ||
    depositOutput.lockingScript.toHex().toLowerCase() !==
      expected.lockingScript.toHex().toLowerCase()
  ) {
    throw new Error('Deposit output is not payable to this service')
  }
  if (
    !Number.isSafeInteger(depositOutput.satoshis) ||
    depositOutput.satoshis < 100
  ) {
    throw new Error('Deposit is too small to refund')
  }
  const validatedAt = Date.now()

  const remittance = await deterministicRefundDerivation(
    depositTxid,
    outputIndex,
  )
  const refundRecipient = senderKey(senderIdentityKey).deriveChild(
    expected.root,
    invoiceNumber(
      remittance.derivationPrefix,
      remittance.derivationSuffix,
    ),
  )
  const derivedAt = Date.now()
  const refund = new Transaction()
  refund.addInput({
    sourceTransaction: deposit,
    sourceOutputIndex: outputIndex,
    unlockingScriptTemplate: new P2PKH().unlock(expected.child),
  })
  refund.addOutput({
    lockingScript: new P2PKH().lock(
      refundRecipient.toAddress('mainnet'),
    ),
    change: true,
  })
  await refund.fee(new SatoshisPerKilobyte(TX_BOUNCE_FEE_RATE))
  if (!refund.outputs[0]?.satoshis || refund.outputs[0].satoshis <= 0) {
    throw new Error('Deposit does not cover the refund fee')
  }
  await refund.sign()
  const signedAt = Date.now()

  let receipt
  let broadcastWarning
  try {
    receipt = await submitChainedPackage(deposit, refund, fetchImpl, ctx)
  } catch (error) {
    broadcastWarning =
      error instanceof Error ? error.message : String(error)
    console.warn(
      '[tx-bounce] signed refund awaiting wallet broadcast',
      refund.id('hex'),
      broadcastWarning,
    )
    receipt = { provider: 'wallet-fallback', status: 0 }
  }
  const submittedAt = Date.now()
  return {
    status: 'ok',
    depositTxid,
    refundTxid: refund.id('hex'),
    outputIndex: 0,
    inputSatoshis: depositOutput.satoshis,
    refundSatoshis: refund.outputs[0].satoshis,
    feeSatoshis: depositOutput.satoshis - refund.outputs[0].satoshis,
    atomicBeef: Array.from(refund.toAtomicBEEF()),
    remittance,
    senderIdentityKey: expected.root.toPublicKey().toString(),
    provider: receipt.provider,
    providerStatus: receipt.status,
    broadcastPending: Boolean(broadcastWarning),
    broadcastWarning,
    timings: {
      parseDepositMs: parsedAt - startedAt,
      validateDepositMs: validatedAt - parsedAt,
      deriveRefundMs: derivedAt - validatedAt,
      buildAndSignMs: signedAt - derivedAt,
      providerSubmitMs: submittedAt - signedAt,
      totalMs: submittedAt - startedAt,
    },
  }
}

export async function handleTxBounce(
  request,
  env,
  url,
  fetchImpl = fetch,
  ctx,
) {
  if (!url.pathname.startsWith('/v1/tx-bounce')) return null
  if (request.method === 'OPTIONS') return json({}, 204)

  try {
    if (
      request.method === 'GET' &&
      url.pathname === '/v1/tx-bounce/config'
    ) {
      const root = serviceKey(env)
      return json({
        identityKey: root.toPublicKey().toString(),
        amountSats: TX_BOUNCE_AMOUNT_SATS,
        protocolID: TX_BOUNCE_PROTOCOL_ID,
      })
    }

    if (
      request.method === 'POST' &&
      url.pathname === '/v1/tx-bounce/prepare'
    ) {
      const body = await requestBody(request)
      const expected = expectedDeposit(
        env,
        body?.senderIdentityKey,
        String(body?.derivationPrefix || '').trim(),
        String(body?.derivationSuffix || '').trim(),
      )
      return json({
        lockingScript: expected.lockingScript.toHex(),
        amountSats: TX_BOUNCE_AMOUNT_SATS,
        outputIndex: 0,
      })
    }

    if (
      request.method === 'POST' &&
      url.pathname === '/v1/tx-bounce/refund'
    ) {
      const body = await requestBody(request)
      const cacheKey = body?.txid
        ? `tx-bounce:${String(body.txid).toLowerCase()}:${Number(body.outputIndex ?? 0)}`
        : null
      if (cacheKey && env?.KV) {
        const cached = await env.KV.get(cacheKey, 'json')
              if (cached) {
                if (
                  !Array.isArray(cached.atomicBeef) &&
                  cached.atomicBeef &&
                  typeof cached.atomicBeef === 'object'
                ) {
                  cached.atomicBeef = Object.entries(cached.atomicBeef)
                    .sort(([left], [right]) => Number(left) - Number(right))
                    .map(([, byte]) => Number(byte))
                }
                return json(cached)
              }
      }
      const result = await buildBounceRefund(body, env, fetchImpl, ctx)
      if (env?.KV) {
        await env.KV.put(
          `tx-bounce:${result.depositTxid}:${Number(body.outputIndex ?? 0)}`,
          JSON.stringify(result),
          { expirationTtl: 7 * 24 * 60 * 60 },
        )
      }
      return json(result)
    }
  } catch (error) {
    const description =
      error instanceof Error ? error.message : String(error)
    const unavailable =
      description.includes('not configured') ||
      description.includes('No transaction provider')
    return json(
      {
        status: 'error',
        code: unavailable
          ? 'TX_BOUNCE_UNAVAILABLE'
          : 'INVALID_TX_BOUNCE_REQUEST',
        description,
      },
      unavailable ? 503 : 400,
    )
  }

  return json(
    {
      status: 'error',
      code: 'NOT_FOUND',
      description: 'Transaction bounce endpoint not found',
    },
    404,
  )
}
