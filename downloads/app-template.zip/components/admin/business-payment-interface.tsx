"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Send, Wallet, RefreshCw } from "lucide-react"

interface Balance {
  spendableBalances: {
    items: Array<{
      spendableBalance: number
      currencyCode: string
    }>
  }
  allBalances: {
    items: Array<{
      currency: {
        code: string
        logoUrl: string
        symbol: string
      }
      units: number
      fiatEquivalent: {
        currencyCode: string
        units: number
      }
    }>
  }
}

export function BusinessPaymentInterface() {
  const [balance, setBalance] = useState<Balance | null>(null)
  const [isLoadingBalance, setIsLoadingBalance] = useState(true)
  const [isSending, setIsSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Form state
  const [destination, setDestination] = useState("")
  const [amount, setAmount] = useState("")
  const [description, setDescription] = useState("")
  const [instrument, setInstrument] = useState("BSV")

  const fetchBalance = async () => {
    setIsLoadingBalance(true)
    setError(null)
    try {
      const response = await fetch("/api/admin/balance", {
        credentials: "include",
      })

      if (!response.ok) {
        setError("Enable business wallet to use this feature")
        setIsLoadingBalance(false)
        return
      }

      const data = await response.json()
      setBalance(data)
    } catch (err) {
      console.error("[v0] Business balance fetch error:", err)
      setError("Enable business wallet to use this feature")
    } finally {
      setIsLoadingBalance(false)
    }
  }

  useEffect(() => {
    fetchBalance()
  }, [])

  const handleSendPayment = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSending(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/admin/payments/send", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          destination,
          amount,
          instrument,
          description,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Payment failed")
      }

      setSuccess(`Payment sent successfully! Transaction ID: ${data.data?.transactionId || "N/A"}`)
      setDestination("")
      setAmount("")
      setDescription("")
      fetchBalance()
    } catch (err: any) {
      console.error("[v0] Business payment error:", err)
      setError(err.message || "Failed to send payment")
    } finally {
      setIsSending(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Balance Card */}
      <Card className="p-4 rounded-3xl border-border">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-bold">Business Wallet Balance</h3>
          </div>
          <Button variant="ghost" size="sm" onClick={fetchBalance} disabled={isLoadingBalance} className="rounded-full h-8 w-8 p-0">
            <RefreshCw className={`w-4 h-4 ${isLoadingBalance ? "animate-spin" : ""}`} />
          </Button>
        </div>

        {isLoadingBalance ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : error && !balance ? (
          <div className="flex flex-col items-center justify-center py-12 px-4">
            <Wallet className="w-14 h-14 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center text-base">Enable business wallet to use this feature</p>
          </div>
        ) : balance ? (
          <div className="space-y-4">
            {balance.spendableBalances?.items && balance.spendableBalances.items.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">Spendable Balance</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {balance.spendableBalances.items.map((item) => {
                    const allBalanceItem = balance.allBalances?.items?.find((b) => b.currency.code === item.currencyCode)
                    const usdValue =
                      item.currencyCode === "BSV" && allBalanceItem?.fiatEquivalent && allBalanceItem.units > 0
                        ? (item.spendableBalance / allBalanceItem.units) * allBalanceItem.fiatEquivalent.units
                        : null

                    return (
                      <div key={item.currencyCode} className="p-3 bg-gradient-to-br from-muted to-muted/80 rounded-xl border border-border/50">
                        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">{item.currencyCode}</div>
                        <div className={`font-bold tracking-tight break-all ${item.currencyCode === "BSV" ? "text-lg mb-1" : "text-xl mb-1"}`}>
                          {item.spendableBalance.toFixed(item.currencyCode === "BSV" ? 8 : 2)}
                        </div>
                        {usdValue !== null && (
                          <div className="text-xs text-muted-foreground font-medium">
                            ≈ ${usdValue.toFixed(2)} {allBalanceItem?.fiatEquivalent?.currencyCode || "USD"}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {balance.allBalances?.items && balance.allBalances.items.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wide">Total Balance</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {balance.allBalances.items.map((item) => (
                    <div key={item.currency.code} className="p-3 bg-gradient-to-br from-background to-muted/30 rounded-xl border border-border/50">
                      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">{item.currency.code}</div>
                      <div className={`font-bold tracking-tight break-all mb-1 ${item.currency.code === "BSV" ? "text-lg" : "text-xl"}`}>
                        {item.units.toFixed(item.currency.code === "BSV" ? 8 : 2)}
                      </div>
                      {item.currency.code === "BSV" && item.fiatEquivalent && (
                        <div className="text-xs text-muted-foreground font-medium">
                          ≈ ${item.fiatEquivalent.units.toFixed(2)} {item.fiatEquivalent.currencyCode}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground text-sm mb-1">No balance data available</p>
            <p className="text-xs text-muted-foreground/70">Business wallet balance will appear here</p>
          </div>
        )}
      </Card>

      {/* Payment Form */}
      <Card className="p-6 rounded-3xl border-border">
        <div className="flex items-center gap-3 mb-6">
          <Send className="w-6 h-6 text-primary" />
          <h3 className="text-xl font-bold">Send Payment</h3>
        </div>

        {error && !balance ? (
          <div className="flex flex-col items-center justify-center py-12 px-4">
            <Send className="w-14 h-14 text-muted-foreground mb-4" />
            <p className="text-muted-foreground text-center text-base">Enable business wallet to use this feature</p>
          </div>
        ) : (
        <form onSubmit={handleSendPayment} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="destination" className="font-semibold">
              Recipient (Handle, Paymail, or Address)
            </Label>
            <Input
              id="destination"
              type="text"
              placeholder="@username or user@handcash.io or 1A1z..."
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              required
              className="rounded-2xl h-12"
            />
          </div>

          <div className="space-y-2">
            <Label className="font-semibold">
              Payment Instrument
            </Label>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setInstrument("BSV")}
                className={`flex-1 h-12 rounded-xl border-2 font-semibold text-base transition-all ${
                  instrument === "BSV"
                    ? "bg-primary text-primary-foreground border-primary shadow-md"
                    : "bg-background hover:bg-muted border-border hover:border-primary/50"
                }`}
              >
                BSV
              </button>
              <button
                type="button"
                onClick={() => setInstrument("MNEE")}
                className={`flex-1 h-12 rounded-xl border-2 font-semibold text-base transition-all ${
                  instrument === "MNEE"
                    ? "bg-primary text-primary-foreground border-primary shadow-md"
                    : "bg-background hover:bg-muted border-border hover:border-primary/50"
                }`}
              >
                MNEE
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount" className="font-semibold">
              Amount (USD)
            </Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              min="0"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
              className="rounded-2xl h-12 text-lg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="font-semibold">
              Message (Optional)
            </Label>
            <Textarea
              id="description"
              placeholder="Add a note to your payment..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="rounded-2xl"
            />
          </div>

          {error && (
            <Alert variant="destructive" className="rounded-2xl">
              <AlertDescription className="font-medium">{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="rounded-2xl border-primary/50 bg-primary/5">
              <AlertDescription className="text-primary font-semibold">{success}</AlertDescription>
            </Alert>
          )}

          <Button type="submit" className="w-full rounded-full h-14 text-lg font-bold" disabled={isSending}>
            {isSending ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Sending Payment...
              </>
            ) : (
              <>
                <Send className="w-5 h-5 mr-2" />
                Send Payment
              </>
            )}
          </Button>
        </form>
        )}
      </Card>
    </div>
  )
}

