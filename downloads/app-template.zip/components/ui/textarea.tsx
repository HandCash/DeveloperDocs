'use client'

import * as React from 'react'
import { Textarea as ChakraTextarea } from '@chakra-ui/react'

import { cn } from '@/lib/utils'

/**
 * HandCash Template Textarea — Chakra v3 Textarea wrapped to preserve the
 * shadcn API. Tailwind classes still drive sizing/colors; Chakra handles the
 * underlying state and accessibility.
 */
const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.ComponentProps<typeof ChakraTextarea>
>(function Textarea({ className, ...props }, ref) {
  return (
    <ChakraTextarea
      ref={ref}
      data-slot="textarea"
      className={cn(
        'border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm',
        className,
      )}
      {...props}
    />
  )
})

export { Textarea }
